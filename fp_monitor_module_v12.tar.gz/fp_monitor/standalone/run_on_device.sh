#!/usr/bin/env bash
#
# run_on_device.sh — install the standalone build on a rooted device and test it
#                    without touching the (read-only) vendor partition.
#
#   ./run_on_device.sh                 # /data/local/tmp, probe + smoke test
#   ./run_on_device.sh --dir=/data/adb # Magisk-style location
#   ./run_on_device.sh --loop          # run the daemon in the foreground
#
# The vendor HAL library must sit next to the binary (the binary's RUNPATH covers
# /data/local/tmp, /data/adb and /data/adb/modules/fp_monitor); this script pulls
# it off the device and installs it for you.
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
BIN="$HERE/out/fp_monitor"
DIR=/data/local/tmp
MODE=smoke
VENDOR_SO=vendor.xiaomi.hardware.fingerprintextension@1.0.so

for a in "$@"; do
    case "$a" in
        --dir=*) DIR="${a#--dir=}" ;;
        --loop) MODE=loop ;;
        *) echo "unknown option: $a"; exit 2 ;;
    esac
done

[ -x "$BIN" ] || { echo "build it first: ./build_standalone.sh"; exit 1; }

echo "== installing into $DIR"
adb shell "su -c 'mkdir -p $DIR'"
adb push "$BIN" "$DIR/fp_monitor" >/dev/null
if [ ! -f "$HERE/$VENDOR_SO" ]; then
    echo "== pulling $VENDOR_SO off the device"
    adb shell "su -c 'cat /vendor/lib64/$VENDOR_SO'" > "$HERE/$VENDOR_SO"
fi
adb push "$HERE/$VENDOR_SO" "$DIR/" >/dev/null
adb shell "su -c 'chmod 755 $DIR/fp_monitor; ls -l $DIR'"

case "$MODE" in
    loop)
        echo "== running (Ctrl-C stops it)"
        adb shell "su -c '$DIR/fp_monitor --poll-ms=50'"
        ;;
    *)
        echo "== probe (config + HAL resolution)"
        adb shell "su -c 'logcat -c; $DIR/fp_monitor --probe; echo ==== once ====; $DIR/fp_monitor --once; echo ==== log ====; logcat -d -s fp_monitor'"
        ;;
esac
