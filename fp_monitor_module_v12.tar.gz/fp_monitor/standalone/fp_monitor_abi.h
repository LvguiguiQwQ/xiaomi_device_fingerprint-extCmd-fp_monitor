/*
 * fp_monitor_abi.h
 *
 * ABI-compatible stand-in for the hidl-gen generated header
 *
 *     vendor/xiaomi/hardware/fingerprintextension/1.0/IXiaomiFingerprint.h
 *
 * Only needed for out-of-tree builds (no AOSP, therefore no generated headers
 * and no android.hidl.base@1.0 IBase.h).  fp_monitor.cc prefers the real
 * generated header whenever it is on the include path.
 *
 * ---------------------------------------------------------------------------
 * How this was derived (measured on a Xiaomi M2102J2SC, Android 16)
 * ---------------------------------------------------------------------------
 * /vendor/lib64/vendor.xiaomi.hardware.fingerprintextension@1.0.so is a normal
 * HIDL interface library and exports its whole client side, including
 *
 *   T  IXiaomiFingerprint::getService(std::string const&, bool)
 *   D  IXiaomiFingerprint::descriptor
 *   T  BpHwXiaomiFingerprint::extCmd(uint32_t, uint32_t)
 *
 * so we only have to call the exported getService() and then invoke extCmd()
 * through the returned object's vtable.
 *
 * The vtable slot cannot be computed as "vtable size / 8 - 3": the interface
 * uses virtual bases, so the vtable starts with a negative prologue
 * (vcall offset, offset-to-top, typeinfo) and the object's vptr points *after*
 * it.  The authoritative slot comes from the library's own generated code --
 * BnHwXiaomiFingerprint::_hidl_extCmd() dispatches exactly the same call:
 *
 *     b7e4:  ldr  x8, [x21, #120]   ; x8 = IXiaomiFingerprint* (implementation)
 *     b808:  ldr  x8, [x0]          ; vptr
 *     b80c:  ldr  x9, [x8, #104]    ; vtable[13]
 *     b814:  blr  x9                ; call with `this` = the interface pointer
 *
 * => extCmd lives in **slot 13** (byte offset 104).
 *
 * fp_monitor.cc does not hard-code that number: at connect time it resolves
 * BpHwXiaomiFingerprint::extCmd with dlsym() and locates it inside the actual
 * object vtable, falling back to kIXiaomiFingerprint_ExtCmdSlot only when the
 * symbol is not visible.  That is what makes the binary portable across ROM
 * versions; see standalone/abicheck.sh for the automated verification.
 */

#ifndef FP_MONITOR_ABI_H
#define FP_MONITOR_ABI_H

#include <cstdint>
#include <string>

#include <hidl/Status.h>          // android::hardware::Return<>
#include <utils/RefBase.h>        // android::RefBase
#include <utils/StrongPointer.h>  // android::sp<>

namespace vendor {
namespace xiaomi {
namespace hardware {
namespace fingerprintextension {
namespace V1_0 {

/*
 * Minimal declaration of the generated interface class.
 *
 * It deliberately declares no virtual functions: the object returned by
 * getService() is a BpHwXiaomiFingerprint built inside the vendor library, and
 * the call is issued through that object's own vtable.  We only need the class
 * as a handle, so android::sp<>/android::RefBase bookkeeping (both real and
 * therefore ABI-correct) keeps working.
 */
class IXiaomiFingerprint : public ::android::RefBase {
  public:
    // Implemented by vendor.xiaomi.hardware.fingerprintextension@1.0.so.
    static ::android::sp<IXiaomiFingerprint> getService(const std::string& serviceName,
                                                        bool getStub);

    // Implemented by vendor.xiaomi.hardware.fingerprintextension@1.0.so.
    static const char* descriptor;
};

/*
 * Slot of extCmd() in the vtable of an IXiaomiFingerprint*.
 *
 * Only used as a fallback: fp_monitor.cc prefers to locate the vendor's own
 * BpHwXiaomiFingerprint::extCmd address inside the object's vtable at runtime.
 */
constexpr int kIXiaomiFingerprint_ExtCmdSlot = 13;

}  // namespace V1_0
}  // namespace fingerprintextension
}  // namespace hardware
}  // namespace xiaomi
}  // namespace vendor

#endif  // FP_MONITOR_ABI_H
