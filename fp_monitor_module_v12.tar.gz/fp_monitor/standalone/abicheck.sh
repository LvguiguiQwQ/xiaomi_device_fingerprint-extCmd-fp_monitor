#!/usr/bin/env bash
#
# abicheck.sh — everything that can be verified without running the binary.
#
#   1. the real vtable slot is read out of the *vendor library itself*
#      (BnHwXiaomiFingerprint::_hidl_extCmd dispatches exactly the call we make)
#      and compared with the fallback constant in standalone/fp_monitor_abi.h;
#   2. both compile paths build, and the "real generated header" style dispatch
#      lands in that same slot;
#   3. the undefined getService symbol our object file references is exactly the
#      one the vendor library exports;
#   4. the linked binary has no unresolved symbol outside its NEEDED libraries.
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
SRC_TOP="${FP_SRC_TOP:-/root/build/src}"
SYSROOT="${FP_SYSROOT:-/root/build/termux/data/data/com.termux/files/usr}"
LIBS="${FP_LIBS:-/root/build/lib}"
VENDOR_SO="$LIBS/vendor.xiaomi.hardware.fingerprintextension@1.0.so"
LIBHIDL="$SRC_TOP/android_system_libhidl-lineage-18.1"
LIBCXX="${FP_LIBCXX:-$SRC_TOP/android_external_libcxx-lineage-18.1/include}"
CORE="$SRC_TOP/android_system_core-lineage-18.1"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

FLAGS=(
    --target=aarch64-linux-android29 --sysroot="$SYSROOT"
    -fPIE -O2 -nostdinc++
    -D_LIBCPP_SUPPORT_XLOCALE_POSIX_L_FALLBACK_H
    -isystem "$SYSROOT/include/aarch64-linux-android"
    -isystem "$LIBCXX"
    -I"$LIBHIDL/base/include" -I"$LIBHIDL/transport/include"
    -I"$CORE/libutils/include" -I"$CORE/libcutils/include"
)

fail=0
note() { printf '  %s\n' "$*"; }

echo "== 1. authoritative slot, read from the vendor library's own code"
VENDOR_SLOT="$(python3 - "$VENDOR_SO" <<'PYEOF'
import re, subprocess, sys
so = sys.argv[1]
sym = None
for line in subprocess.run(['readelf','-sW','--dyn-syms',so],capture_output=True,text=True).stdout.splitlines():
    p = line.split()
    if len(p) >= 8 and 'BnHwXiaomiFingerprint12_hidl_extCmd' in p[7]:
        sym = p[7]
if sym is None:
    sys.exit(1)
dis = subprocess.run(['objdump','-d','--disassemble=' + sym, so],
                     capture_output=True, text=True).stdout.splitlines()
last = None
for line in dis:
    m = re.search(r'ldr\s+x(\d+), \[x\d+, #(\d+)\]', line)
    if m:
        last = (m.group(1), int(m.group(2)))
    m = re.search(r'blr\s+x(\d+)', line)
    if m and last and m.group(1) == last[0]:
        print(last[1] // 8)
        break
PYEOF
)" || true

if [ -z "${VENDOR_SLOT:-}" ]; then
    note "could not derive the slot from $VENDOR_SO"
    fail=1
else
    note "vendor library dispatches extCmd through vtable slot $VENDOR_SLOT"
fi

HEADER_SLOT="$(sed -n 's/.*kIXiaomiFingerprint_ExtCmdSlot *= *\([0-9]*\).*/\1/p' "$HERE/fp_monitor_abi.h")"
note "standalone/fp_monitor_abi.h fallback constant : $HEADER_SLOT"
if [ -n "${VENDOR_SLOT:-}" ] && [ "$VENDOR_SLOT" != "$HEADER_SLOT" ]; then
    note "MISMATCH between vendor library and header constant"
    fail=1
fi

echo "== 2. both compile paths, and the compile-time dispatch"
clang++ "${FLAGS[@]}" -I"$HERE" -I"$HERE/.." -c "$HERE/../fp_monitor.cc" -o "$TMP/shim.o"
note "standalone (ABI shim)             : compiles OK"
clang++ "${FLAGS[@]}" -I"$HERE/abicheck/mock_include" -I"$HERE/.." \
    -c "$HERE/../fp_monitor.cc" -o "$TMP/header.o"
note "generated-header style (fixture)  : compiles OK"
objdump -d "$TMP/header.o" > "$TMP/header.dis"   # no pipe: grep -q + pipefail is unreliable
if grep -qE "ldr[[:space:]]+x[0-9]+, \[x[0-9]+, #$((VENDOR_SLOT * 8))\]" "$TMP/header.dis"; then
    note "compile-time dispatch uses slot $VENDOR_SLOT (offset $((VENDOR_SLOT * 8))) OK"
else
    note "compile-time dispatch does not use offset $((VENDOR_SLOT * 8))"
    fail=1
fi

echo "== 3. symbols"
ours="$(nm -u "$TMP/shim.o" | awk '/IXiaomiFingerprint10getService/ {print $2}' | head -1)"
theirs="$(nm -D --defined-only "$VENDOR_SO" | awk '/IXiaomiFingerprint10getService/ {print $3}' | head -1)"
if [ -n "$ours" ] && [ "$ours" = "$theirs" ]; then
    note "getService mangled name matches the vendor library OK"
else
    note "getService MISMATCH"; note "  ours:   $ours"; note "  vendor: $theirs"; fail=1
fi
if nm -D --defined-only "$VENDOR_SO" | grep -q 'BpHwXiaomiFingerprint6extCmdEjj'; then
    note "vendor exports BpHwXiaomiFingerprint::extCmd (runtime slot detection possible) OK"
else
    note "vendor does not export BpHwXiaomiFingerprint::extCmd -- runtime auto-detect unavailable"
fi

echo "== 4. linked binary"
BIN="$HERE/out/fp_monitor"
if [ ! -f "$BIN" ]; then
    note "no binary yet (run build_standalone.sh first) -- skipped"
else
    set +e
    python3 - "$BIN" "$LIBS" <<'PYEOF'
import re, subprocess, sys
binp, libs = sys.argv[1], sys.argv[2]
need = re.findall(r'\[([^\]]+\.so)\]',
                  subprocess.run(['readelf','-d',binp],capture_output=True,text=True).stdout)
def defineds(l):
    out = subprocess.run(['nm','-D','--defined-only',f'{libs}/{l}'],capture_output=True,text=True).stdout
    return {ln.split()[-1].split('@')[0] for ln in out.splitlines() if len(ln.split()) >= 3}
def undefs():
    out = subprocess.run(['nm','-u',binp],capture_output=True,text=True).stdout
    return [ln.split()[1].split('@')[0] for ln in out.splitlines()
            if len(ln.split()) >= 2 and ln.split()[0] == 'U']
have = set()
for l in need:
    have |= defineds(l)
missing = [s for s in undefs() if s not in have]
print(f"  NEEDED {len(need)} libs, undefined refs {len(undefs())}, unresolved {len(missing)}")
for m in missing:
    print("   MISSING:", m)
sys.exit(1 if missing else 0)
PYEOF
    rc=$?
    set -e
    if [ $rc -eq 0 ]; then note "all references resolved OK"; else note "unresolved references"; fail=1; fi
fi

if [ "$fail" = "0" ]; then echo "ABI CHECK PASSED"; else echo "ABI CHECK FAILED"; exit 1; fi
