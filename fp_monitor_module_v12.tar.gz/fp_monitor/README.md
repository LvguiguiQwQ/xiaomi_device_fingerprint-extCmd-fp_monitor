# fp_monitor

把设备的 FOD（指纹高亮）状态桥接到小米指纹扩展 HAL。**逻辑是 `libmisurfaceflinger.so` 里
`FodMonitorThread::threadLoop()` 的 1:1 移植**，不自创设计。

## 0. misf 原文（反汇编还原）

```c
// readyToRun():
fd_fod  = open("/sys/class/drm/card0-DSI-1/fod_ui_ready");
fd_disp = open("/dev/mi_display/disp_feature");
ioctl(fd_disp, MI_DISP_IOCTL_REGISTER_EVENT /*_IOW('D',7,12)*/, &req);   // 注册 Backlight/Fod/Brightness_clone/Doze 四类事件
ioctl(fd_disp, MI_DISP_IOCTL_GET_BRIGHTNESS /*_IOWR('D',11,16)*/, &br);

// threadLoop():
poll(&pfd_fod, 1, -1);                    // ★ 只等 fod_ui_ready 这一个 fd，阻塞
pread(fd_fod, buf, 16, 0);
unsigned long v = strtoul(buf, NULL, 10); // 按十进制解析
if (v == 3) {
    DisplayFeatureIntf::setFeature(0, 24, 1, 0);
    log("fod capture start");
    if (mSleepMs) usleep(mSleepMs * 1000);
    sendCmd(10, 1);                       // → extCmd(10, 1)
    mFodCapture = true;
} else if (v == 7) {
    log("fod capture start");
    if (mSleepMs) usleep(mSleepMs * 1000);
    sendCmd(10, 6);                       // → extCmd(10, 6)
    mFodCapture = true;
} else {
    if (!mFodCapture) return;             // 没点过亮就不发停止
    DisplayFeatureIntf::setFeature(0, 24, 0, 0);
    log("fod capture stop");
    sendCmd(10, 0);                       // → extCmd(10, 0)
    mFodCapture = false;
}
```

要点：

- **misf 不轮询，是 poll 通知**（kernfs 的 `sysfs_notify`），所以反应是即时的、CPU 占用 ~0。
- **`v == 3` 才是正常按下** → `extCmd(10, 1)`；`v == 7` 是另一条支路 → `extCmd(10, 6)`；
  其它值（含 0/1/2）→ 如果之前点过，就 `extCmd(10, 0)`。
  真机日志完全吻合：`fod_ui_ready:3` 之后 3ms 就是 `extCmd: cmd=10, param=1`，
  `fod_ui_ready:1` 之后就是 `param=0`。
- `FingerprintStateManager::sendCmd(int,int)` 是**原样透传**给 HAL 的（无映射），
  所以上面写的数字就是最终 `extCmd` 的参数。raphael 与 Mi 10S 一致，不存在"机型差异"。
- `setDisplayParam()`（写 disp_param）/ `WriteFPStatusToKernel()`（写 touch_finger_status）
  由 misf 的**其它线程**（`updateFodFlag` / `lowBrightnessFOD` 等）调用，不在本状态机里。

## 1. 本程序与 misf 的对应关系

| misf | 本程序 |
|---|---|
| `poll(fod_ui_ready, -1)` | 同一份：`poll(fd, POLLPRI)`；不支持通知时才退化成 `poll_ms` 轮询 |
| `strtoul(buf, NULL, 10)` | 数字比较（`0xe0000`≡`0x000E0000`，`3`≡`03`） |
| `v == 3` | `mifod.path.param`（必填） |
| `sendCmd(10, 1)` | `mifod.cmd` + `mifod.down`（必填） |
| `v == 7` → `sendCmd(10, 6)` | `mifod.alt.value` + `mifod.alt.param`（可选，不填就忽略这条支路） |
| `else` → `sendCmd(10, 0)` | `mifod.up`（必填） |
| `if (!mFodCapture) return;` | 同样的 `m_capture` 判定，不会凭空发停止 |
| `usleep(mSleepMs * 1000)` | `mifod.sleep_ms`（默认 0，即 misf 默认行为） |
| `DisplayFeatureIntf::setFeature(0,24,1/0,0)` | **未实现**（另一个 HAL，需要的话再加） |
| （misf 不做）| `mifod.highlight.*`：**opt-in**，只在 ROM 里没人点高亮时用 |

## 2. 属性

必填 6 个（无默认值，缺哪个就打印哪个并退出）：

| 属性 | 命令行 | 对应 misf | 示例 |
|---|---|---|---|
| `mifod.path` | `--path=` | `fod_ui_ready` | `/sys/class/drm/card0-DSI-1/fod_ui_ready` |
| `mifod.path.param` | `--path-param=` | `v == 3` 的 `3` | `3` |
| `mifod.down` | `--down=` | `sendCmd(10, 1)` 的 `1` | `1` |
| `mifod.up` | `--up=` | `sendCmd(10, 0)` 的 `0` | `0` |
| `mifod.mode` | `--mode=` | 选 AIDL/HIDL | `hidl` |
| `mifod.cmd` | `--cmd=` | `sendCmd(10, ·)` 的 `10` | `10` |

可选：

| 属性 | 命令行 | 默认 | 说明 |
|---|---|---|---|
| `mifod.alt.value` | `--alt-value=` | 空=关 | 第二条支路的值（misf 的 `7`） |
| `mifod.alt.param` | `--alt-param=` | `6` | 该支路的参数（misf 的 `6`） |
| `mifod.sleep_ms` | `--sleep-ms=` | `0` | misf 的 `mSleepMs` |
| `mifod.poll_ms` | `--poll-ms=` | `5` | 仅在不支持 poll 通知时用到 |
| `mifod.slot` | `--slot=` | `0`=自动 | HIDL 虚表槽位兜底 |
| `mifod.instance` | `--instance=` | `default` | HIDL 实例 |
| `mifod.aidl_iface` / `mifod.aidl_code` | `--aidl-iface=` / `--aidl-code=` | 小米 AIDL 名 / `1` | AIDL 后端 |
| `mifod.guard` / `mifod.debug` | `--guard=` / `--debug=` | `1` / `0` | 崩溃保护 / 详细日志 |
| `mifod.highlight.path` / `.on` / `.off` | `--highlight-path=` 等 | 空=关 / `0x70000` / `0x80000` | **非 misf 行为**，见下 |

```bash
setprop mifod.path /sys/class/drm/card0-DSI-1/fod_ui_ready
setprop mifod.path.param 3
setprop mifod.down 1
setprop mifod.up 0
setprop mifod.mode hidl
setprop mifod.cmd 10
```

## 3. `highlight.*` 什么时候才用

misf 的这套状态机**不写 disp_param**（高亮由 SF 的其它线程/显示驱动负责）。
所以只有在你的 ROM 里"没人点高亮"（比如 MI-SF 被裁掉）时才需要让 daemon 代劳：

```bash
setprop mifod.highlight.path /sys/class/drm/card0-DSI-1/disp_param
setprop mifod.highlight.on <实测能亮的那个值>     # 用 --write 试：默认 0x70000 在有些面板不亮
setprop mifod.highlight.off <空闲读回值>
fp_monitor --highlight-path=/sys/class/drm/card0-DSI-1/disp_param --write=0x20000   # 试值
```

顺序是 `写高亮 → （sleep_ms）→ extCmd(cmd, down)`，抬起是 `extCmd(cmd, up) → 写高亮`。

## 4. 诊断

| 命令 | 作用 |
|---|---|
| `--probe` | 打印节点当前值、配置、HAL 连接、扫描到的虚表槽位（**不调用 extCmd**，属性不齐也能用） |
| `--scan[=DIR1,DIR2]` | 监视目录下所有可读节点，打印变化（`CHANGED +0.292s .../fod_ui_ready : "2" -> "3"`） |
| `--write=VALUE` | 往 `highlight.path` 写一次值后退出（试高亮值） |
| `--once` | 读一次 + 走一次状态机 |
| `--dry-run` | 只观察，不调用 HAL |

## 5. 编译 / 部署

```bash
cp -r fp_monitor <aosp>/hardware/xiaomi/ && cp fp_monitor.te <aosp>/system/sepolicy/vendor/
m fp_monitor                                  # AOSP 树内
./standalone/build_standalone.sh && ./standalone/abicheck.sh    # 脱离 AOSP
./standalone/run_on_device.sh [--dir=/data/adb] [--loop]
```

HAL 库要和二进制同目录（RUNPATH 含 `/data/local/tmp`、`/data/adb`、`/data/adb/modules/fp_monitor`）。
init 服务：`setprop mifod.*` 或把 `--path=` 等参数写在 rc 里。

## 6. 验证

`standalone/abicheck.sh`：从设备上的 `.so` 反汇编读出真实虚表槽位（13）与代码常量比对；
两条编译路径都过；链接后无未解析符号。

## 7. 还没做的

1. `setFeature(0,24,1/0,0)`（`vendor.xiaomi.hardware.displayfeature`）没实现 —— misf 会调，
   需要的话告诉我，我照抄那个接口。
2. `MI_DISP_IOCTL_*`（`/dev/mi_display/disp_feature`）没用到 —— misf 只用它读亮度/注册事件，
   本程序的触发源就是 `poll(fod_ui_ready)`，和 misf 的 poll 完全一样，不需要它。
3. 本机设备 shell 禁止执行 /data 下自编程序，运行行为要在目标设备上验。
4. sepolicy 未编译过（没有 AOSP 树）。
