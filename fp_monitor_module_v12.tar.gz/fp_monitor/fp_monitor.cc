/*
 * fp_monitor — bridge between a device's FOD (fingerprint on display) state and
 *              the fingerprint extension HAL, modelled on the official MIUI
 *              implementation (libmisurfaceflinger.so, reverse engineered).
 *
 * Official behaviour (MIUI, Xiaomi Mi 10S class devices)
 * -----------------------------------------------------
 *   FodMonitorThread     polls the display's FOD state (fod_ui_ready node and
 *                        the MI_DISP_EVENT_FOD display event) and, on
 *                        "fod capture start"/"stop":
 *                          extCmd(10, 6)  /  extCmd(10, 0)
 *                        It also drives the panel highlight by *writing*
 *                        "0x%x" to /sys/class/drm/card0-DSI-1/disp_param:
 *                          setFODFlag(true)  -> 0x70000
 *                          setFODFlag(false) -> 0x80000
 *                          fp status         -> (status | 0xE000)
 *   TouchMonitorThread   reads /dev/input events to notice finger down/up.
 *
 * On several devices disp_param is write-only (reads back empty) and the HAL
 * refuses to work unless the panel has been told to highlight -- hence the
 * optional mifod.highlight.* writeback below.
 *
 * The numeric values (cmd / down / up / highlight on|off / the ready value) are
 * per ROM build, not per device model: always take them from your own ROM, i.e.
 *     logcat -d | grep -E "fingerprintextension|goodix_extCmd"
 * prints lines like
 *     vendor...fingerprintextension@1.0: extCmd: cmd=10, param=1
 *     [GF_HAL]: [goodix_extCmd] HBM and Green spot ready
 * and `fp_monitor --scan` shows which node changes (and to which value) when the
 * fingerprint UI comes up.  This daemon hard-codes none of that.
 *
 * Configuration: six required properties, no built-in defaults
 * ------------------------------------------------------------
 *   setprop mifod.path       /sys/class/drm/card0-DSI-1/fod_ui_ready
 *   setprop mifod.path.param 0            value meaning "no fingerprint UI"
 *   setprop mifod.down       6            extCmd parameter on finger-down (official: 6)
 *   setprop mifod.up         0            extCmd parameter on finger-up   (official: 0)
 *   setprop mifod.mode       hidl         hidl | aidl | none
 *   setprop mifod.cmd        10           extCmd command id (official: 10)
 *
 * If any of them is missing the process logs which one and exits.
 *
 * Optional:
 *   mifod.highlight.path              node to *write* to light the FOD panel
 *                                     (e.g. /sys/class/drm/card0-DSI-1/disp_param)
 *   mifod.highlight.on  [0x70000]     value written when the FOD becomes active
 *   mifod.highlight.off [0x80000]     value written when it goes idle
 *   mifod.poll_ms       [5]           poll period in ms (poll() is used when the
 *                                     node supports notifications -> instant)
 *   mifod.slot          [0=auto]      HIDL vtable slot fallback
 *   mifod.instance      [default]     HIDL instance name
 *   mifod.aidl_iface / mifod.aidl_code [1]
 *   mifod.guard [1] / mifod.debug [0]
 *
 * Discovery helpers:
 *   fp_monitor --scan[=DIR1,DIR2]   watch every readable node below the given
 *                                   directories and print the ones that change
 *                                   -- this is how the right trigger node is
 *                                   found on an unknown device
 *   fp_monitor --probe              print configuration, node value, HAL state
 *
 * Build (AOSP):       m fp_monitor
 * Build (standalone): standalone/build_standalone.sh
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#define LOG_TAG "fp_monitor"

#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <time.h>
#include <unistd.h>

#include <hidl/Status.h>
#include <utils/RefBase.h>
#include <utils/StrongPointer.h>

/* ------------------------------------------------------------------ logging */

#if defined(__has_include)
#if __has_include(<log/log.h>)
#include <log/log.h>
#define FP_HAVE_LIBLOG 1
#endif
#endif

#ifndef FP_HAVE_LIBLOG
extern "C" int __android_log_print(int prio, const char* tag, const char* fmt, ...);
#define ALOGI(...) __android_log_print(4 /*ANDROID_LOG_INFO*/, LOG_TAG, __VA_ARGS__)
#define ALOGW(...) __android_log_print(5 /*ANDROID_LOG_WARN*/, LOG_TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(6 /*ANDROID_LOG_ERROR*/, LOG_TAG, __VA_ARGS__)
#endif

/* ---------------------------------------------------------- HIDL client side */

#if defined(__has_include)
#if __has_include(<vendor/xiaomi/hardware/fingerprintextension/1.0/IXiaomiFingerprint.h>)
#define FP_HAVE_HIDL_HEADER 1
#endif
#endif

#ifdef FP_HAVE_HIDL_HEADER
#include <vendor/xiaomi/hardware/fingerprintextension/1.0/IXiaomiFingerprint.h>
#else
#include "fp_monitor_abi.h"
#include <dlfcn.h>
#endif

using ::android::sp;
using ::android::hardware::Return;
using ::android::hardware::Status;
using ::vendor::xiaomi::hardware::fingerprintextension::V1_0::IXiaomiFingerprint;

#ifndef FP_HAVE_HIDL_HEADER
using ::vendor::xiaomi::hardware::fingerprintextension::V1_0::kIXiaomiFingerprint_ExtCmdSlot;
#endif

/* -------------------------------------------------------------- configuration */

#define FP_PROP "mifod."

static int64_t now_us() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<int64_t>(ts.tv_sec) * 1000000 + ts.tv_nsec / 1000;
}

struct Config {
    /* required */
    std::string path;
    std::string path_param;
    int32_t down = 0;
    int32_t up = 0;
    std::string mode;
    int32_t cmd = 0xa;
    bool path_set = false, path_param_set = false, down_set = false, up_set = false;
    bool mode_set = false, cmd_set = false;

    /* optional */
    std::string alt_value;        /* second trigger value (misf: 7 -> param 6) */
    int32_t alt_param = 6;
    int sleep_ms = 0;             /* misf: FodMonitorThread::mSleepMs before sendCmd */
    std::string highlight_path;   /* empty = no writeback */
    int32_t highlight_on = 0x70000;
    int32_t highlight_off = 0x80000;
    int poll_ms = 5;
    int hidl_slot = 0;
    std::string hidl_instance = "default";
    std::string aidl_iface =
            "vendor.xiaomi.hardware.fingerprintextension.IXiaomiFingerprint/default";
    int aidl_code = 1;
    bool guard = true;
    bool debug = false;
};

static Config g_cfg;

static void log_config() {
    ALOGI("config: path=%s path.param=%s down=%d up=%d mode=%s cmd=%d poll=%dms guard=%d debug=%d",
          g_cfg.path.c_str(), g_cfg.path_param.c_str(), static_cast<int>(g_cfg.down),
          static_cast<int>(g_cfg.up), g_cfg.mode.c_str(), static_cast<int>(g_cfg.cmd), g_cfg.poll_ms,
          g_cfg.guard ? 1 : 0, g_cfg.debug ? 1 : 0);
    if (!g_cfg.alt_value.empty()) {
        ALOGI("config: alt value %s -> extCmd(%d, %d)", g_cfg.alt_value.c_str(),
              static_cast<int>(g_cfg.cmd), static_cast<int>(g_cfg.alt_param));
    }
    if (g_cfg.sleep_ms) {
        ALOGI("config: sleep %dms before extCmd (misf mSleepMs)", g_cfg.sleep_ms);
    }
    if (!g_cfg.highlight_path.empty()) {
        ALOGI("config: highlight %s on=0x%x off=0x%x", g_cfg.highlight_path.c_str(),
              static_cast<unsigned>(g_cfg.highlight_on), static_cast<unsigned>(g_cfg.highlight_off));
    }
    if (g_cfg.mode == "hidl") {
        ALOGI("config: hidl instance=%s slot=%s", g_cfg.hidl_instance.c_str(),
              g_cfg.hidl_slot == 0 ? "auto" : std::to_string(g_cfg.hidl_slot).c_str());
    } else if (g_cfg.mode == "aidl") {
        ALOGI("config: aidl iface=%s code=%d", g_cfg.aidl_iface.c_str(), g_cfg.aidl_code);
    }
}

/* ---------------------------------------------------------- property helpers */

static bool prop_get(const std::string& name, std::string* out) {
    char buf[PROP_VALUE_MAX] = {0};
    int n = __system_property_get(name.c_str(), buf);
    if (n <= 0) {
        return false;
    }
    *out = buf;
    return true;
}

static bool prop_get_bool(const std::string& name, bool* out) {
    std::string v;
    if (!prop_get(name, &v)) {
        return false;
    }
    *out = strtol(v.c_str(), nullptr, 0) != 0;
    return true;
}

static bool prop_get_int(const std::string& name, int* out) {
    std::string v;
    if (!prop_get(name, &v)) {
        return false;
    }
    *out = static_cast<int>(strtol(v.c_str(), nullptr, 0));
    return true;
}

static void load_config_from_properties() {
    std::string v;

    if (prop_get(FP_PROP "path", &v) && !v.empty()) {
        g_cfg.path = v;
        g_cfg.path_set = true;
    }
    if (prop_get(FP_PROP "path.param", &v) && !v.empty()) {
        g_cfg.path_param = v;
        g_cfg.path_param_set = true;
    }
    if (prop_get(FP_PROP "down", &v) && !v.empty()) {
        g_cfg.down = static_cast<int32_t>(strtol(v.c_str(), nullptr, 0));
        g_cfg.down_set = true;
    }
    if (prop_get(FP_PROP "up", &v) && !v.empty()) {
        g_cfg.up = static_cast<int32_t>(strtol(v.c_str(), nullptr, 0));
        g_cfg.up_set = true;
    }
    if (prop_get(FP_PROP "mode", &v) && !v.empty()) {
        g_cfg.mode = v;
        g_cfg.mode_set = true;
    }
    if (prop_get_int(FP_PROP "cmd", &g_cfg.cmd)) {
        g_cfg.cmd_set = true;
    }

    prop_get(FP_PROP "alt.value", &g_cfg.alt_value);
    prop_get_int(FP_PROP "alt.param", &g_cfg.alt_param);
    prop_get_int(FP_PROP "sleep_ms", &g_cfg.sleep_ms);
    prop_get(FP_PROP "highlight.path", &g_cfg.highlight_path);
    prop_get_int(FP_PROP "highlight.on", &g_cfg.highlight_on);
    prop_get_int(FP_PROP "highlight.off", &g_cfg.highlight_off);
    prop_get_int(FP_PROP "poll_ms", &g_cfg.poll_ms);
    prop_get_int(FP_PROP "slot", &g_cfg.hidl_slot);
    prop_get(FP_PROP "instance", &g_cfg.hidl_instance);
    prop_get(FP_PROP "aidl_iface", &g_cfg.aidl_iface);
    prop_get_int(FP_PROP "aidl_code", &g_cfg.aidl_code);
    prop_get_bool(FP_PROP "guard", &g_cfg.guard);
    prop_get_bool(FP_PROP "debug", &g_cfg.debug);
}

/* Missing required configuration is a hard error: never invent behaviour. */
static int report_missing_properties() {
    struct Req {
        bool set;
        const char* key;
        const char* example;
    };
    const Req reqs[] = {
            {g_cfg.path_set, "path", "/sys/class/drm/card0-DSI-1/fod_ui_ready"},
            {g_cfg.path_param_set, "path.param", "3"},
            {g_cfg.down_set, "down", "6"},
            {g_cfg.up_set, "up", "0"},
            {g_cfg.mode_set, "mode", "hidl"},
            {g_cfg.cmd_set, "cmd", "10"},
    };
    const int total = static_cast<int>(sizeof(reqs) / sizeof(reqs[0]));
    int missing = 0;
    for (const Req& r : reqs) {
        if (!r.set) {
            missing++;
        }
    }
    if (missing == 0) {
        return 0;
    }
    ALOGE("missing required configuration (%d of %d):", missing, total);
    for (const Req& r : reqs) {
        if (!r.set) {
            ALOGE("  setprop %s%s %s", FP_PROP, r.key, r.example);
        }
    }
    return 1;
}

/* -------------------------------------------------------- value comparison */

/*
 * Accepts "0x000E0000", "0xe0000", "917504" and "000E0000" (hex fallback).
 * Returns false for anything that is not a number at all.
 */
static bool parse_number(const std::string& s, long long* out) {
    if (s.empty()) {
        return false;
    }
    char* end = nullptr;
    errno = 0;
    long long v = strtoll(s.c_str(), &end, 0);
    if (errno == 0 && end != s.c_str() && *end == '\0') {
        *out = v;
        return true;
    }
    end = nullptr;
    errno = 0;
    v = strtoll(s.c_str(), &end, 16);
    if (errno == 0 && end != s.c_str() && *end == '\0') {
        *out = v;
        return true;
    }
    return false;
}

/*
 * mifod.path.param / mifod.alt.value are compared numerically against the node
 * value, so 0xe0000 == 0x000E0000 and 3 == 03; string compare otherwise.
 */
static bool value_matches(const std::string& value, const std::string& wanted) {
    long long v = 0, w = 0;
    if (parse_number(value, &v) && parse_number(wanted, &w)) {
        return v == w;
    }
    return value == wanted;
}

static bool value_is_press(const std::string& value) {
    return value_matches(value, g_cfg.path_param);
}

static bool value_is_alt(const std::string& value) {
    return !g_cfg.alt_value.empty() && value_matches(value, g_cfg.alt_value);
}

/* --------------------------------------------------------------- fault guard */

/*
 * A wrong HAL ABI (unknown ROM) must produce a log line, not a SIGSEGV and a
 * dead daemon.  The guarded region is one indirect call with POD arguments, so
 * siglongjmp() out of it cannot leak C++ objects.
 */
static sigjmp_buf g_fault_jmp;
static volatile sig_atomic_t g_in_guard = 0;
static bool g_guard_ready = false;

static void fault_handler(int sig, siginfo_t* /*info*/, void* /*ctx*/) {
    if (g_in_guard) {
        g_in_guard = 0;
        siglongjmp(g_fault_jmp, 1);
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static void install_fault_guard() {
    if (g_guard_ready) {
        return;
    }
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = fault_handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGBUS, &sa, nullptr);
    g_guard_ready = true;
}

/* ------------------------------------------------------------------ detection */

/*
 * The trigger node is opened once and read with pread(); when the kernel
 * supports notifications for it poll() wakes us the moment it changes, which
 * makes the reaction time ~0 instead of one poll period.  If poll() returns
 * immediately over and over without the value changing, notifications are not
 * supported and we fall back to sleeping poll_ms between reads.
 */
struct NodeSource {
    int fd = -1;
    bool poll_ok = true;
    int immediate = 0;
    bool warned_empty = false;
};

static NodeSource g_src;

static bool node_open() {
    if (g_src.fd >= 0) {
        return true;
    }
    int fd = open(g_cfg.path.c_str(), O_RDONLY | O_CLOEXEC | O_NONBLOCK);
    if (fd < 0) {
        return false;
    }
    g_src.fd = fd;
    g_src.poll_ok = true;
    g_src.immediate = 0;
    return true;
}

static void node_close() {
    if (g_src.fd >= 0) {
        close(g_src.fd);
        g_src.fd = -1;
    }
}

/* 1 = value in *out (may be empty), 0 = read failed (fd closed) */
static int node_read(std::string* out) {
    if (g_src.fd < 0) {
        return 0;
    }
    char buf[128] = {0};
    ssize_t n = pread(g_src.fd, buf, sizeof(buf) - 1, 0);
    if (n < 0) {
        int saved = errno;
        if (saved == ESPIPE) { /* seq_file style node: needs lseek */
            if (lseek(g_src.fd, 0, SEEK_SET) >= 0) {
                n = read(g_src.fd, buf, sizeof(buf) - 1);
                saved = errno;
            }
        }
        if (n < 0) {
            node_close();
            errno = saved;
            return 0;
        }
    }
    for (ssize_t i = n; i > 0; i--) {
        if (buf[i - 1] == '\n' || buf[i - 1] == '\r' || buf[i - 1] == ' ' || buf[i - 1] == '\t') {
            buf[i - 1] = '\0';
        } else {
            break;
        }
    }
    *out = buf;
    return 1;
}

/* Wait for a change (or the timeout).  Returns true if poll() reported one. */
static bool node_wait(int timeout_ms) {
    if (g_src.fd < 0) {
        usleep(timeout_ms * 1000);
        return false;
    }
    if (!g_src.poll_ok) {
        usleep(timeout_ms * 1000);
        return false;
    }
    struct pollfd p = {g_src.fd, POLLPRI | POLLERR, 0};
    int64_t t0 = now_us();
    int r = poll(&p, 1, timeout_ms);
    int64_t dt = now_us() - t0;
    if (r > 0 && dt < 2000) {
        if (++g_src.immediate > 8) {
            g_src.poll_ok = false;
            ALOGI("%s does not support poll notifications; polling every %dms",
                  g_cfg.path.c_str(), g_cfg.poll_ms);
        }
    }
    return r > 0;
}

/*
 * Official FOD highlight control: MIUI's FodMonitorThread::setDisplayParam()
 * does fopen(path, "w") + fprintf("0x%x", value) on disp_param.  Same here.
 * Returns true when a value was written.
 */
static bool highlight_write(int32_t value) {
    if (g_cfg.highlight_path.empty()) {
        return false;
    }
    int fd = open(g_cfg.highlight_path.c_str(), O_WRONLY | O_CLOEXEC);
    if (fd < 0) {
        ALOGW("highlight: cannot open %s: %s", g_cfg.highlight_path.c_str(), strerror(errno));
        return false;
    }
    char buf[32];
    int len = snprintf(buf, sizeof(buf), "0x%x", static_cast<unsigned>(value));
    ssize_t n = write(fd, buf, len);
    int saved = errno;
    close(fd);
    if (n != len) {
        ALOGW("highlight: write %s to %s failed: %s", buf, g_cfg.highlight_path.c_str(),
              strerror(saved));
        return false;
    }
    ALOGI("highlight: %s <- %s", g_cfg.highlight_path.c_str(), buf);
    return true;
}

/* ------------------------------------------------------------- node scanner */

/*
 * fp_monitor --scan[=dir1,dir2]
 *
 * Walks the given directories (default: the FOD/touch ones used by MIUI),
 * keeps every readable regular file open, and prints the ones whose content
 * changes.  Touch the sensor while it runs: the node that reacts is the trigger
 * this daemon should be pointed at.
 */
static void collect_files(const std::string& dir, int depth, std::vector<std::string>* out) {
    DIR* d = opendir(dir.c_str());
    if (d == nullptr) {
        return;
    }
    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        if (e->d_name[0] == '.') {
            continue;
        }
        std::string p = dir + "/" + e->d_name;
        struct stat st;
        if (stat(p.c_str(), &st) != 0) {
            continue;
        }
        if (S_ISDIR(st.st_mode)) {
            if (depth > 0) {
                collect_files(p, depth - 1, out);
            }
        } else if (S_ISREG(st.st_mode)) {
            if (access(p.c_str(), R_OK) == 0) {
                out->push_back(p);
            }
        }
    }
    closedir(d);
}

static std::string read_file(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NONBLOCK);
    if (fd < 0) {
        return "<open failed>";
    }
    char buf[256] = {0};
    ssize_t n = pread(fd, buf, sizeof(buf) - 1, 0);
    close(fd);
    if (n <= 0) {
        return "<empty>";
    }
    std::string s(buf, n);
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ')) {
        s.pop_back();
    }
    return s;
}

static int scan(const std::string& dirs_arg, int interval_ms) {
    std::vector<std::string> dirs;
    std::string cur;
    std::string arg = dirs_arg.empty()
            ? "/sys/class/drm,/sys/class/touch,/sys/class/touchscreen,/sys/class/leds"
            : dirs_arg;
    for (char c : arg) {
        if (c == ',') {
            if (!cur.empty()) dirs.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    if (!cur.empty()) {
        dirs.push_back(cur);
    }

    std::vector<std::string> files;
    for (const auto& d : dirs) {
        collect_files(d, 2, &files);
    }
    if (files.empty()) {
        ALOGE("scan: no readable files below the given directories");
        return 1;
    }
    ALOGI("scan: watching %zu files (%dms) -- touch the sensor now", files.size(), interval_ms);

    std::vector<std::string> values(files.size());
    for (size_t i = 0; i < files.size(); i++) {
        values[i] = read_file(files[i]);
    }
    int64_t t0 = now_us();
    while (true) {
        usleep(interval_ms * 1000);
        for (size_t i = 0; i < files.size(); i++) {
            std::string v = read_file(files[i]);
            if (v != values[i]) {
                ALOGI("CHANGED %+.3fs %s : \"%s\" -> \"%s\"",
                      (now_us() - t0) / 1000000.0, files[i].c_str(), values[i].c_str(), v.c_str());
                printf("CHANGED %+.3fs %s : \"%s\" -> \"%s\"\n", (now_us() - t0) / 1000000.0,
                       files[i].c_str(), values[i].c_str(), v.c_str());
                fflush(stdout);
                values[i] = v;
            }
        }
    }
    return 0;
}

/* ----------------------------------------------------------- HIDL back-end */

static sp<IXiaomiFingerprint> g_service;
static int g_hidl_slot = -1;

#ifdef FP_HAVE_HIDL_HEADER
#define FP_EXTCMD_SYMBOL nullptr /* compile-time dispatch, no dlsym needed */
#else
#define FP_EXTCMD_SYMBOL \
    "_ZN6vendor6xiaomi8hardware20fingerprintextension4V1_021BpHwXiaomiFingerprint6extCmdEjj"
#endif

/*
 * Find extCmd()'s vtable slot on the *actual* object.
 *
 * The vendor library exports its own proxy implementation
 * (BpHwXiaomiFingerprint::extCmd); when that address is present in the object's
 * vtable we know the slot without a hard-coded number.  On this device it is
 * slot 13 (byte offset 104), taken from the library's own generated server code
 * which dispatches the very same call:
 *
 *     ldr x8, [x0]        ; vptr
 *     ldr x9, [x8, #104]  ; vtable[13]
 *     blr x9
 *
 * (The vtable symbol has a 3 word negative prologue -- vcall offset,
 * offset-to-top, typeinfo -- which is why "last virtual" != "last word".)
 */
static int resolve_hidl_slot(IXiaomiFingerprint* service) {
    void** vptr = *reinterpret_cast<void***>(service);
    if (vptr == nullptr) {
        return -1;
    }
#ifdef FP_HAVE_HIDL_HEADER
    return -1; /* compile-time dispatch on this path */
#else
    void* direct = dlsym(RTLD_DEFAULT, FP_EXTCMD_SYMBOL);
    if (direct != nullptr) {
        for (int i = 0; i < 64; i++) {
            if (vptr[i] == direct) {
                return i;
            }
        }
    }
    if (g_cfg.hidl_slot > 0) {
        return g_cfg.hidl_slot;
    }
    return kIXiaomiFingerprint_ExtCmdSlot;
#endif
}

static bool hidl_connect() {
    if (g_service != nullptr) {
        return true;
    }
    g_service = IXiaomiFingerprint::getService(g_cfg.hidl_instance, false);
    if (g_service == nullptr) {
        ALOGW("getService(\"%s\") returned null", g_cfg.hidl_instance.c_str());
        return false;
    }
    ALOGI("connected: %s", IXiaomiFingerprint::descriptor);
#ifndef FP_HAVE_HIDL_HEADER
    g_hidl_slot = resolve_hidl_slot(g_service.get());
    if (g_hidl_slot < 0) {
        ALOGE("cannot determine extCmd vtable slot");
        g_service = nullptr;
        return false;
    }
    void* direct = dlsym(RTLD_DEFAULT, FP_EXTCMD_SYMBOL);
    ALOGI("extCmd: vtable slot %d (byte %d), direct symbol %p%s", g_hidl_slot, g_hidl_slot * 8,
          direct, direct == nullptr ? " (not exported: using configured slot)" : "");
    if (g_cfg.hidl_slot > 0 && g_hidl_slot != g_cfg.hidl_slot) {
        ALOGW("configured slot=%d but auto-detected slot=%d; using the detected one",
              g_cfg.hidl_slot, g_hidl_slot);
    }
#endif
    return true;
}

/* Returns: 1 = call done, 0 = transport error, -1 = process fault (ABI mismatch) */
static int hidl_call(int32_t param, int32_t* result) {
    if (g_service == nullptr) {
        return 0;
    }
#ifdef FP_HAVE_HIDL_HEADER
    Return<int32_t> ret = g_service->extCmd(g_cfg.cmd, param);
    if (!ret.isOk()) {
        return 0;
    }
    *result = static_cast<int32_t>(ret);
    return 1;
#else
    void** vptr = *reinterpret_cast<void***>(g_service.get());
    if (vptr == nullptr || g_hidl_slot < 0) {
        return 0;
    }
    typedef Return<int32_t> (*ExtCmdFn)(void*, int32_t, int32_t);
    ExtCmdFn fn = reinterpret_cast<ExtCmdFn>(vptr[g_hidl_slot]);
    if (fn == nullptr) {
        return 0;
    }
    if (g_cfg.guard && g_guard_ready) {
        if (sigsetjmp(g_fault_jmp, 1) != 0) {
            return -1;
        }
        g_in_guard = 1;
        Return<int32_t> ret = fn(g_service.get(), g_cfg.cmd, param);
        g_in_guard = 0;
        if (!ret.isOk()) {
            return 0;
        }
        *result = static_cast<int32_t>(ret);
        return 1;
    }
    Return<int32_t> ret = fn(g_service.get(), g_cfg.cmd, param);
    if (!ret.isOk()) {
        return 0;
    }
    *result = static_cast<int32_t>(ret);
    return 1;
#endif
}

/* ----------------------------------------------------------- AIDL back-end */

/*
 * Generic AIDL client: the interface is looked up in servicemanager and the
 * method is issued as a raw transaction, so no generated AIDL code is needed.
 * The method is assumed to be `int extCmd(int cmd, int param)`, the shape of
 * every known Xiaomi fingerprint extension interface.
 */
#if defined(__has_include)
#if __has_include(<android/binder_manager.h>)
#include <android/binder_manager.h>
#define FP_HAVE_BINDER_MANAGER_HEADER 1
#endif
#if __has_include(<android/binder_ibinder.h>) && __has_include(<android/binder_parcel.h>)
#include <android/binder_ibinder.h>
#include <android/binder_parcel.h>
#define FP_HAVE_BINDER_NDK_HEADERS 1
#endif
#endif

#ifndef FP_HAVE_BINDER_NDK_HEADERS
#define FP_HAVE_BINDER_NDK_HEADERS 0
#endif

#if !FP_HAVE_BINDER_NDK_HEADERS
typedef struct AIBinder AIBinder;
#endif

#if !FP_HAVE_BINDER_MANAGER_HEADER && FP_HAVE_BINDER_NDK_HEADERS
extern "C" AIBinder* AServiceManager_getService(const char* instance);
#endif

static AIBinder* g_aidl_binder = nullptr;

static bool aidl_connect() {
    if (g_aidl_binder != nullptr) {
        return true;
    }
    if (!FP_HAVE_BINDER_NDK_HEADERS) {
        ALOGE("built without libbinder_ndk headers, aidl backend unavailable");
        return false;
    }
    g_aidl_binder = AServiceManager_getService(g_cfg.aidl_iface.c_str());
    if (g_aidl_binder == nullptr) {
        ALOGW("AServiceManager_getService(\"%s\") returned null", g_cfg.aidl_iface.c_str());
        return false;
    }
    ALOGI("connected: %s", g_cfg.aidl_iface.c_str());
    return true;
}

/* Returns: 1 = call done, 0 = transport error, -1 = process fault */
static int aidl_call(int32_t param, int32_t* result) {
#if !FP_HAVE_BINDER_NDK_HEADERS
    (void)param;
    (void)result;
    return 0;
#else
    if (g_aidl_binder == nullptr) {
        return 0;
    }
    if (g_cfg.guard && g_guard_ready) {
        if (sigsetjmp(g_fault_jmp, 1) != 0) {
            return -1;
        }
        g_in_guard = 1;
    }
    int rc = 0;
    AParcel* data = nullptr;
    AParcel* reply = nullptr;
    if (AIBinder_prepareTransaction(g_aidl_binder, &data) != STATUS_OK ||
        AParcel_writeInt32(data, g_cfg.cmd) != STATUS_OK ||
        AParcel_writeInt32(data, param) != STATUS_OK ||
        AIBinder_transact(g_aidl_binder, g_cfg.aidl_code, &data, &reply, 0) != STATUS_OK ||
        reply == nullptr || AParcel_readInt32(reply, result) != STATUS_OK) {
        rc = 0;
    } else {
        rc = 1;
    }
    if (reply != nullptr) {
        AParcel_delete(reply);
    }
    if (g_cfg.guard && g_guard_ready) {
        g_in_guard = 0;
    }
    return rc;
#endif
}

/* ------------------------------------------------------------------ dispatch */

static bool g_backend_broken = false;

static void backend_send(int32_t param) {
    if (g_cfg.mode == "none") {
        ALOGI("mode=none: would call extCmd(%d, %d)", static_cast<int>(g_cfg.cmd),
              static_cast<int>(param));
        return;
    }
    if (g_backend_broken) {
        return;
    }
    bool connected = (g_cfg.mode == "aidl") ? aidl_connect() : hidl_connect();
    if (!connected) {
        return;
    }
    int32_t result = 0;
    int rc = (g_cfg.mode == "aidl") ? aidl_call(param, &result) : hidl_call(param, &result);

    if (rc == -1) {
        g_backend_broken = true;
        ALOGE("FATAL: the %s call faulted (bad vtable slot / ABI mismatch). HAL disabled, still "
              "watching %s. Set %smode none to silence, or fix %sslot.",
              g_cfg.mode.c_str(), g_cfg.path.c_str(), FP_PROP, FP_PROP);
        return;
    }
    if (rc == 0) {
        ALOGW("extCmd(%d, %d) failed on %s backend -- will reconnect", static_cast<int>(g_cfg.cmd),
              static_cast<int>(param), g_cfg.mode.c_str());
        g_service = nullptr;
        g_aidl_binder = nullptr;
        return;
    }
    ALOGI("extCmd(%d, %d) -> %d", static_cast<int>(g_cfg.cmd), static_cast<int>(param),
          static_cast<int>(result));
}

/*
 * Faithful port of MIUI FodMonitorThread::threadLoop():
 *
 *     v = strtoul(fod_ui_ready, NULL, 10);
 *     if (v == 3)      { setFeature(0,24,1,0); "fod capture start"; usleep(mSleepMs); sendCmd(10, 1); mFodCapture = true; }
 *     else if (v == 7) {                       "fod capture start"; usleep(mSleepMs); sendCmd(10, 6); mFodCapture = true; }
 *     else             { if (!mFodCapture) return; setFeature(0,24,0,0); "fod capture stop"; sendCmd(10, 0); mFodCapture = false; }
 *
 * mifod.path.param is the first value (3 above), mifod.alt.value/param the
 * second one (7 -> 6), mifod.up the "everything else" parameter (0) and
 * mifod.sleep_ms the mSleepMs delay.  mifod.highlight.* is not part of misf;
 * it exists only for ROMs where nothing else lights the panel.
 */
static bool g_fod_capture = false;

static void on_value(const std::string& value) {
    bool first = !value.empty() && value_matches(value, g_cfg.path_param);
    bool alt = value_is_alt(value);

    if (first || alt) {
        /* misf re-sends the start command whenever it sees 3/7 again -- no guard */
        highlight_write(g_cfg.highlight_on);
        if (g_cfg.sleep_ms > 0) {
            usleep(g_cfg.sleep_ms * 1000);
        }
        backend_send(first ? g_cfg.down : g_cfg.alt_param);
        g_fod_capture = true;
        return;
    }

    if (!g_fod_capture) {
        return; /* misf: nothing to stop */
    }
    backend_send(g_cfg.up);
    highlight_write(g_cfg.highlight_off);
    g_fod_capture = false;
}

/* ---------------------------------------------------------------- CLI/probe */

static void usage(const char* argv0) {
    fprintf(stderr,
            "usage: %s [options]\n\n"
            "Required configuration -- as properties, or as the matching option.\n"
            "There are no built-in defaults: a missing one makes the process exit.\n\n"
            "  %spath=<path>       --path=PATH        node to watch (readable!)\n"
            "  %spath.param=<v>    --path-param=VAL   value while the FOD highlight is READY\n"
            "  %sdown=<n>          --down=N           extCmd parameter, finger down\n"
            "  %sup=<n>            --up=N             extCmd parameter, finger up\n"
            "  %smode=<name>       --mode=hidl|aidl|none\n"
            "  %scmd=<n>           --cmd=N            extCmd command id (official 10)\n\n"
            "Example (values are per ROM build -- read yours as shown below):\n"
            "  setprop %spath /sys/class/drm/card0-DSI-1/fod_ui_ready\n"
            "  setprop %spath.param 3        # value while the highlight is ready\n"
            "  setprop %sdown 1              # from: logcat | grep 'extCmd: cmd='\n"
            "  setprop %sup 0                #   \"HBM and Green spot ready\" -> down\n"
            "  setprop %smode hidl\n"
            "  setprop %scmd 10\n"
            "  setprop %shighlight.path /sys/class/drm/card0-DSI-1/disp_param\n"
            "  setprop %shighlight.on 0x20000   # value that really lights it (see --write)\n"
            "  setprop %shighlight.off 0xE0000  # the idle read-back value\n\n"
            "Find your values:\n"
            "  logcat -d | grep -E 'fingerprintextension|goodix_extCmd'   # cmd/param + meaning\n"
            "  %s --scan                                        # which node changes\n"
            "  %s --highlight-path=PATH --write=0x20000         # does this light the FOD?\n\n"
            "Optional:\n"
            "  %salt.value=VAL        --alt-value=VAL      second trigger value (misf: 7)\n"
            "  %salt.param=N (%d)     --alt-param=N        its extCmd parameter (misf: 6)\n"
            "  %ssleep_ms=N (%d)      --sleep-ms=N         misf mSleepMs before extCmd\n"
            "  %shighlight.path=PATH  --highlight-path=PATH  write the FOD highlight here\n"
            "  %shighlight.on=N (0x%x) --highlight-on=N\n"
            "  %shighlight.off=N (0x%x) --highlight-off=N\n"
            "  %spoll_ms=N (%d)        --poll-ms=N\n"
            "  %sslot=N (0=auto)      --slot=N\n"
            "  %sinstance=NAME        --instance=NAME\n"
            "  %saidl_iface=NAME      --aidl-iface=NAME\n"
            "  %saidl_code=N (%d)     --aidl-code=N\n"
            "  %sguard=0|1 (%d) / %sdebug=0|1 (%d)\n\n"
            "Actions:\n"
            "  --probe                print node value, configuration and HAL state, then exit\n"
            "  --write=VALUE          write VALUE to %shighlight.path once, then exit\n"
            "                         (use this to find the value that really lights the FOD)\n"
            "  --scan[=DIR1,DIR2]     watch readable nodes and print which ones change\n"
            "  --once                 one detect + one HAL round-trip, then exit\n"
            "  --dry-run              never call the HAL, only log transitions\n"
            "  --help\n",
            argv0,
            /* required (6) */
            FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP,
            /* example (9) */
            FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP, FP_PROP,
            /* find-your-values helpers (2) */
            argv0, argv0,
            /* alt.value, alt.param, sleep_ms */
            FP_PROP, FP_PROP, g_cfg.alt_param, FP_PROP, g_cfg.sleep_ms,
            /* highlight.path, on, off, poll_ms */
            FP_PROP, FP_PROP, static_cast<unsigned>(g_cfg.highlight_on), FP_PROP,
            static_cast<unsigned>(g_cfg.highlight_off), FP_PROP, g_cfg.poll_ms,
            /* slot, instance, aidl_iface, aidl_code */
            FP_PROP, FP_PROP, FP_PROP, FP_PROP, g_cfg.aidl_code,
            /* guard, debug */
            FP_PROP, g_cfg.guard ? 1 : 0, FP_PROP, g_cfg.debug ? 1 : 0,
            /* actions: --write=VALUE ... %shighlight.path */
            FP_PROP);
}

static bool arg_value(const char* arg, const char* name, const char** out) {
    size_t len = strlen(name);
    if (strncmp(arg, name, len) != 0) {
        return false;
    }
    if (arg[len] == '=') {
        *out = arg + len + 1;
        return true;
    }
    return arg[len] == '\0' ? (*out = "", true) : false;
}

static int probe() {
    if (g_cfg.path_set) {
        node_open();
    }
    std::string raw;
    bool ok = g_cfg.path_set && node_open() && node_read(&raw) == 1;
    bool state = ok && !raw.empty() && value_is_press(raw);

    printf("path      : %s%s\n", g_cfg.path_set ? g_cfg.path.c_str() : "<not set>",
           g_cfg.path_set ? "" : "   (setprop " FP_PROP "path ...)");
    printf("path.param: %s%s\n", g_cfg.path_param_set ? g_cfg.path_param.c_str() : "<not set>",
           g_cfg.path_param_set ? "" : "   (setprop " FP_PROP "path.param ...)");
    printf("value     : %s%s\n", ok ? ("\"" + raw + "\"").c_str() : "<unreadable>",
           ok ? (raw.empty() ? "  -> EMPTY (write-only node? try --scan)" : (state ? "  -> active" : "  -> idle")) : "");
    printf("mode      : %s%s   cmd=%s%s   down=%s   up=%s\n",
           g_cfg.mode_set ? g_cfg.mode.c_str() : "<not set>",
           g_cfg.mode_set ? "" : "   (setprop " FP_PROP "mode hidl)",
           g_cfg.cmd_set ? std::to_string(g_cfg.cmd).c_str() : "<not set>",
           g_cfg.cmd_set ? "" : "   (setprop " FP_PROP "cmd 10)",
           g_cfg.down_set ? std::to_string(g_cfg.down).c_str() : "<not set>",
           g_cfg.up_set ? std::to_string(g_cfg.up).c_str() : "<not set>");
    if (!g_cfg.alt_value.empty()) {
        printf("alt       : value %s -> extCmd(%d, %d)\n", g_cfg.alt_value.c_str(),
               static_cast<int>(g_cfg.cmd), static_cast<int>(g_cfg.alt_param));
    }
    if (g_cfg.sleep_ms) {
        printf("sleep     : %dms before extCmd\n", g_cfg.sleep_ms);
    }
    printf("highlight : %s", g_cfg.highlight_path.empty() ? "<disabled>" : g_cfg.highlight_path.c_str());
    if (!g_cfg.alt_value.empty()) {
        ALOGI("config: alt value %s -> extCmd(%d, %d)", g_cfg.alt_value.c_str(),
              static_cast<int>(g_cfg.cmd), static_cast<int>(g_cfg.alt_param));
    }
    if (g_cfg.sleep_ms) {
        ALOGI("config: sleep %dms before extCmd (misf mSleepMs)", g_cfg.sleep_ms);
    }
    if (!g_cfg.highlight_path.empty()) {
        printf("  on=0x%x off=0x%x", static_cast<unsigned>(g_cfg.highlight_on),
               static_cast<unsigned>(g_cfg.highlight_off));
    }
    printf("\n");

    if (g_cfg.mode_set && g_cfg.mode == "hidl") {
        bool connected = hidl_connect();
        printf("hidl      : instance=%s connected=%s\n", g_cfg.hidl_instance.c_str(),
               connected ? "yes" : "no");
#ifndef FP_HAVE_HIDL_HEADER
        void* direct = dlsym(RTLD_DEFAULT, FP_EXTCMD_SYMBOL);
        printf("            exported extCmd symbol: %s\n",
               direct ? "found" : "NOT found (will use configured slot)");
        if (connected) {
            void** vptr = *reinterpret_cast<void***>(g_service.get());
            int found = -1;
            for (int i = 0; direct != nullptr && i < 64; i++) {
                if (vptr[i] == direct) {
                    found = i;
                    break;
                }
            }
            printf("            vtable slot: %d%s\n",
                   found >= 0 ? found : resolve_hidl_slot(g_service.get()),
                   found >= 0 ? " (auto-detected)" : " (configured/default)");
        }
#endif
    } else if (g_cfg.mode_set && g_cfg.mode == "aidl") {
        printf("aidl      : iface=%s code=%d connected=%s\n", g_cfg.aidl_iface.c_str(),
               g_cfg.aidl_code, aidl_connect() ? "yes" : "no");
    }
    return 0;
}

/* --------------------------------------------------------------------- main */

int main(int argc, char** argv) {
    load_config_from_properties();

    bool dry_run = false;
    bool once = false;
    bool do_probe = false;
    bool do_scan = false;
    bool have_write = false;
    int32_t write_value = 0;
    std::string scan_dirs;

    for (int i = 1; i < argc; i++) {
        const char* v = nullptr;
        if (strcmp(argv[i], "--help") == 0) {
            usage(argv[0]);
            return 0;
        } else if (strcmp(argv[i], "--probe") == 0) {
            do_probe = true;
        } else if (strcmp(argv[i], "--scan") == 0) {
            do_scan = true;
        } else if (arg_value(argv[i], "--scan", &v)) {
            do_scan = true;
            scan_dirs = v;
        } else if (strcmp(argv[i], "--once") == 0) {
            once = true;
        } else if (strcmp(argv[i], "--dry-run") == 0) {
            dry_run = true;
            g_cfg.mode = "none";
            g_cfg.mode_set = true;
        } else if (arg_value(argv[i], "--path", &v)) {
            g_cfg.path = v;
            g_cfg.path_set = true;
        } else if (arg_value(argv[i], "--path-param", &v)) {
            g_cfg.path_param = v;
            g_cfg.path_param_set = true;
        } else if (arg_value(argv[i], "--down", &v)) {
            g_cfg.down = static_cast<int32_t>(strtol(v, nullptr, 0));
            g_cfg.down_set = true;
        } else if (arg_value(argv[i], "--up", &v)) {
            g_cfg.up = static_cast<int32_t>(strtol(v, nullptr, 0));
            g_cfg.up_set = true;
        } else if (arg_value(argv[i], "--mode", &v)) {
            g_cfg.mode = v;
            g_cfg.mode_set = true;
        } else if (arg_value(argv[i], "--cmd", &v)) {
            g_cfg.cmd = static_cast<int32_t>(strtol(v, nullptr, 0));
            g_cfg.cmd_set = true;
        } else if (arg_value(argv[i], "--alt-value", &v)) {
            g_cfg.alt_value = v;
        } else if (arg_value(argv[i], "--alt-param", &v)) {
            g_cfg.alt_param = static_cast<int32_t>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--sleep-ms", &v)) {
            g_cfg.sleep_ms = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--write", &v)) {
            write_value = static_cast<int32_t>(strtol(v, nullptr, 0));
            have_write = true;
        } else if (arg_value(argv[i], "--highlight-path", &v)) {
            g_cfg.highlight_path = v;
        } else if (arg_value(argv[i], "--highlight-on", &v)) {
            g_cfg.highlight_on = static_cast<int32_t>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--highlight-off", &v)) {
            g_cfg.highlight_off = static_cast<int32_t>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--poll-ms", &v)) {
            g_cfg.poll_ms = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--slot", &v)) {
            g_cfg.hidl_slot = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--instance", &v)) {
            g_cfg.hidl_instance = v;
        } else if (arg_value(argv[i], "--aidl-iface", &v)) {
            g_cfg.aidl_iface = v;
        } else if (arg_value(argv[i], "--aidl-code", &v)) {
            g_cfg.aidl_code = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--guard", &v)) {
            g_cfg.guard = strtol(v, nullptr, 0) != 0;
        } else if (arg_value(argv[i], "--debug", &v)) {
            g_cfg.debug = strtol(v, nullptr, 0) != 0;
        } else {
            fprintf(stderr, "%s: unknown argument '%s'\n", argv[0], argv[i]);
            usage(argv[0]);
            return 2;
        }
    }
    if (g_cfg.poll_ms < 1) {
        g_cfg.poll_ms = 1;
    }

    if (do_scan) {
        return scan(scan_dirs, 10);
    }
    if (have_write) {
        if (g_cfg.highlight_path.empty()) {
            fprintf(stderr, "--write needs %shighlight.path (or --highlight-path=PATH)\n", FP_PROP);
            return 2;
        }
        return highlight_write(write_value) ? 0 : 1;
    }
    if (do_probe) {
        return probe();
    }
    if (report_missing_properties() != 0) {
        return 1;
    }

    log_config();
    if (g_cfg.guard) {
        install_fault_guard();
    }

    if (once) {
        node_open();
        std::string raw;
        bool ok = node_read(&raw) == 1;
        bool state = ok && !raw.empty() && value_is_press(raw);
        ALOGI("state: readable=%d value=\"%s\" finger_down=%d", ok ? 1 : 0, raw.c_str(),
              state ? 1 : 0);
        if (!dry_run) {
            on_value(raw);
        }
        return 0;
    }

    bool last = false; /* silent while idle */
    bool have_raw = false;
    std::string last_raw;
    int fail_count = 0;

    while (true) {
        if (g_src.fd < 0) {
            if (!node_open()) {
                if (++fail_count == 1 || (fail_count % 200) == 0) {
                    ALOGW("cannot open %s: %s (retrying)", g_cfg.path.c_str(), strerror(errno));
                }
                usleep(g_cfg.poll_ms * 1000);
                continue;
            }
            have_raw = false;
        }

        node_wait(g_cfg.poll_ms);

        std::string raw;
        if (node_read(&raw) != 1) {
            if (++fail_count == 1 || (fail_count % 200) == 0) {
                ALOGW("cannot read %s: %s (retrying)", g_cfg.path.c_str(), strerror(errno));
            }
            usleep(g_cfg.poll_ms * 1000);
            continue;
        }
        fail_count = 0;

        if (raw.empty() && !g_src.warned_empty) {
            g_src.warned_empty = true;
            ALOGW("%s reads back empty -- it is probably a write-only node. Use `%s --scan` to "
                  "find a readable trigger (fod_ui_ready / touch_finger_status) and point %spath "
                  "at it; keep this one for %shighlight.path.",
                  g_cfg.path.c_str(), "fp_monitor", FP_PROP, FP_PROP);
        }

        bool now = !raw.empty() && value_is_press(raw);

        if (!have_raw || raw != last_raw) {
            ALOGI("node value: \"%s\" (%s)", raw.c_str(), now ? "pressed" : "released");
            last_raw = raw;
            have_raw = true;
        }

        (void)now;
        (void)last;
        on_value(raw);
    }
    return 0;
}
