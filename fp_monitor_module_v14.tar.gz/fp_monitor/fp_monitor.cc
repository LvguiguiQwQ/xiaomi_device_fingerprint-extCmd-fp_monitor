/*
 * fp_monitor — bridge between a device's FOD (fingerprint on display) state and
 *              the fingerprint extension HAL, modelled on the official MIUI
 *              implementation (libmisurfaceflinger.so, reverse engineered).
 *
 * Official behaviour (MIUI, 小米设备)
 * -----------------------------------------------------
 *   FodMonitorThread     polls the display's FOD state (fod_ui_ready node and
 *                        the MI_DISP_EVENT_FOD display event) and, on
 *                        "fod capture start"/"stop":
 *                          extCmd(10, 6)  /  extCmd(10, 0)
 *                        It also drives the panel highlight by *writing*
 *                        "0x%x" to /sys/class/drm/card0-DSI-1/disp_param:
 *                          setFODFlag(true)  -> 0x70000
 *                          setFODFlag(false) -> 0x80000
 *                          fp status         -> (status | 0xE000)
 *   TouchMonitorThread   reads /dev/input events to notice finger down/up.
 *
 * On several devices disp_param is write-only (reads back empty) and the HAL
 * refuses to work unless the panel has been told to highlight -- hence the
 * optional mifod.highlight.* writeback below.
 *
 * The numeric values (cmd / down / up / highlight on|off / the ready value) are
 * per ROM build, not per device model: always take them from your own ROM, i.e.
 *     logcat -d | grep -E "fingerprintextension|goodix_extCmd"
 * prints lines like
 *     vendor...fingerprintextension@1.0: extCmd: cmd=10, param=1
 *     [GF_HAL]: [goodix_extCmd] HBM and Green spot ready
 * and `fp_monitor --scan` shows which node changes (and to which value) when the
 * fingerprint UI comes up.  This daemon hard-codes none of that.
 *
 * Configuration: six required properties, no built-in defaults
 * ------------------------------------------------------------
 *   setprop mifod.path       /sys/class/drm/card0-DSI-1/fod_ui_ready
 *   setprop mifod.path.param 0            value meaning "no fingerprint UI"
 *   setprop mifod.down       6            extCmd parameter on finger-down (official: 6)
 *   setprop mifod.up         0            extCmd parameter on finger-up   (official: 0)
 *   setprop mifod.mode       hidl         hidl | aidl | none
 *   setprop mifod.cmd        10           extCmd command id (official: 10)
 *
 * If any of them is missing the process logs which one and exits.
 *
 * Optional:
 *   mifod.highlight.path              node to *write* to light the FOD panel
 *                                     (e.g. /sys/class/drm/card0-DSI-1/disp_param)
 *   mifod.highlight.on  [0x70000]     value written when the FOD becomes active
 *   mifod.highlight.off [0x80000]     value written when it goes idle
 *   mifod.poll_ms       [5]           poll period in ms (poll() is used when the
 *                                     node supports notifications -> instant)
 *   mifod.slot          [0=auto]      HIDL vtable slot fallback
 *   mifod.instance      [default]     HIDL instance name
 *   mifod.aidl_iface / mifod.aidl_code [1]
 *   mifod.guard [1] / mifod.debug [0]
 *
 * Discovery helpers:
 *   fp_monitor --scan[=DIR1,DIR2]   watch every readable node below the given
 *                                   directories and print the ones that change
 *                                   -- this is how the right trigger node is
 *                                   found on an unknown device
 *   fp_monitor --probe              print configuration, node value, HAL state
 *
 * Build (AOSP):       m fp_monitor
 * Build (standalone): standalone/build_standalone.sh
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#define LOG_TAG "fp_monitor"

#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cstring>
#include <string>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <time.h>
#include <unistd.h>

#include <hidl/Status.h>
#include <utils/RefBase.h>
#include <utils/StrongPointer.h>

/* ------------------------------------------------------------------ logging */

#if defined(__has_include)
#if __has_include(<log/log.h>)
#include <log/log.h>
#define FP_HAVE_LIBLOG 1
#endif
#endif

#ifndef FP_HAVE_LIBLOG
extern "C" int __android_log_print(int prio, const char* tag, const char* fmt, ...);
#define ALOGI(...) __android_log_print(4 /*ANDROID_LOG_INFO*/, LOG_TAG, __VA_ARGS__)
#define ALOGW(...) __android_log_print(5 /*ANDROID_LOG_WARN*/, LOG_TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(6 /*ANDROID_LOG_ERROR*/, LOG_TAG, __VA_ARGS__)
#endif

/* ---------------------------------------------------------- HIDL client side */

#if defined(__has_include)
#if __has_include(<vendor/xiaomi/hardware/fingerprintextension/1.0/IXiaomiFingerprint.h>)
#define FP_HAVE_HIDL_HEADER 1
#endif
#endif

#ifdef FP_HAVE_HIDL_HEADER
#include <vendor/xiaomi/hardware/fingerprintextension/1.0/IXiaomiFingerprint.h>
#else
#include "fp_monitor_abi.h"
#include <dlfcn.h>
#endif

using ::android::sp;
using ::android::hardware::Return;
using ::android::hardware::Status;
using ::vendor::xiaomi::hardware::fingerprintextension::V1_0::IXiaomiFingerprint;

#ifndef FP_HAVE_HIDL_HEADER
using ::vendor::xiaomi::hardware::fingerprintextension::V1_0::kIXiaomiFingerprint_ExtCmdSlot;
#endif

/* -------------------------------------------------------------- configuration */

#define FP_PROP "mifod."

static int64_t now_us() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<int64_t>(ts.tv_sec) * 1000000 + ts.tv_nsec / 1000;
}

struct Config {
    /* Every setting is optional: each one has a built-in default and the process
     * never exits because something was not configured.  The *_set flags only
     * record whether a property/option supplied the value, for logging. */
    /* ===== misf 的官方取值：写死，不再由属性提供 ===== */
    /* 节点可选：不设置 mifod.path 就完全不读节点 */
    std::string path = "/sys/class/drm/card0-DSI-1/fod_ui_ready";
    std::string path_param = "3";           /* 未设置 = 不启用"就绪"判定 */
    int32_t down = 1;      /* misf 默认值；可被 mifod.extcmd.down 覆盖 */                 /* 未设置 = 该分支不发 */
    int32_t up = 0;        /* misf 默认值；可被 mifod.extcmd.up 覆盖 */
    std::string mode = "auto";        /* misf：AIDL 优先 → HIDL 回退 */
    int32_t cmd = 10;      /* misf 默认值；可被 mifod.extcmd.cmd 覆盖 */                  /* 未设置 = 不发 extCmd */
    bool path_set = true, path_param_set = true, down_set = true, up_set = true;
    bool mode_set = true, cmd_set = true;

    /* trigger source -- some ROMs have no usable FOD node at all (AIDL-only
     * stacks), so the node must not be mandatory for them.  Default = node. */
    /* mifod.runtime.mode：总运行开关。false = 只读节点/只打日志，不发任何命令、不写节点。 */
    bool runtime_mode = true;
    std::string trigger;              /* node | timer | prop */
    int period_ms = 0;                /* timer: unset -> timer trigger skipped */
    int timer_param = 0;              /* timer: unset -> timer trigger skipped */
    std::string prop_name;            /* prop: property to watch */
    std::string prop_param;           /* prop: value that means "pressed" */
    bool timer_param_set = false, period_set = false;
    bool prop_name_set = false, prop_param_set = false;
    bool df_case_set = true, df_on_set = true, df_off_set = true;

    /* optional */
    std::string alt_value;        /* 已停用（第二就绪） */
    int32_t alt_param = 0;
    int sleep_ms = 0;             /* misf: FodMonitorThread::mSleepMs before sendCmd */
    std::string highlight_path = "/sys/class/drm/card0-DSI-1/disp_param";
    int32_t highlight_on = 0x70000;    /* misf 默认值，可覆盖 */
    int32_t highlight_off = 0x80000;
    bool highlight_on_set = true, highlight_off_set = true;
    int poll_ms = 0;              /* 0 = block on the node (no polling period preset) */
    int hidl_slot = 0;
    /* transport constants: fixed by the platform, not policy -- built in */
    std::string hidl_instance = "default";
    std::string aidl_iface =
            "vendor.xiaomi.hardware.fingerprintextension.IXiaomiFingerprint/default";
    int aidl_code = 1;
    bool guard = true;
    bool debug = false;
    bool strict = false;              /* strict=1: missing config exits (old behaviour) */

    /* 可选：改用"读一个系统属性"触发（设置 mifod.prop 才启用） */
    std::string prop_trigger;         /* 要读的系统属性名；值非空且非 "0" 视为按下 */

    /* 可选：用 /dev/input 事件触发（设置 input.device 才启用） */
    std::string input_device;         /* 设备名（uinput-goodix）或 /dev/input/eventN */
    int input_type = 0;               /* 0 = 任意类型（忽略 EV_SYN）；1 = EV_KEY */
    int input_code = 0;               /* 写死：任意 code */
    int input_value_down = 1;         /* 写死：value=1 视为按下 */

    /* displayfeature HAL -- misf's DisplayFeatureIntf::setFeature(0,24,1|0,0) */
    bool df_enable = true;
    std::string df_mode = "hidl";     /* misf：displayfeature 走 HIDL */
    std::string df_instance = "default";
    std::string df_aidl_iface =
            "vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default";
    int df_aidl_code = 7;
    int32_t df_case = 24;             /* misf：FOD capture */
    int32_t df_on = 1;
    int32_t df_off = 0;
    int32_t df_cookie = 0;            /* cookie (misf passes 0) */
};

/* Every log line goes to logcat AND to stdout (flushed immediately), so the
 * output is visible when the binary is started from a terminal, a shell, or a
 * file manager such as MT Manager -- not only in logcat. */
#undef ALOGI
#undef ALOGW
#undef ALOGE
#define FP_LOG(prio, ...)                                         \
    do {                                                          \
        __android_log_print(prio, "fp_monitor", __VA_ARGS__);     \
        fprintf(stdout, __VA_ARGS__);                             \
        fputc('\n', stdout);                                      \
        fflush(stdout);                                           \
    } while (0)
#define ALOGI(...) FP_LOG(4, __VA_ARGS__)
#define ALOGW(...) FP_LOG(5, __VA_ARGS__)
#define ALOGE(...) FP_LOG(6, __VA_ARGS__)

static Config g_cfg;

/* Debug trace: visible on the terminal as well as in logcat, so a hang can be
 * located by looking at the last "[step]" line printed.  Silent unless
 * mifod.debug / --debug is given. */
static void dbglog(const char* fmt, ...) {
    if (!g_cfg.debug) {
        return;
    }
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    fprintf(stdout, "fp_monitor[%d]: %s\n", static_cast<int>(getpid()), buf);
    fflush(stdout);
    ALOGI("%s", buf);
}

static const char* effective_trigger();


/* ---------------------------------------------------------- property helpers */

static bool prop_get(const std::string& name, std::string* out) {
    char buf[PROP_VALUE_MAX] = {0};
    int n = __system_property_get(name.c_str(), buf);
    if (n <= 0) {
        return false;
    }
    *out = buf;
    return true;
}


static bool prop_get_int(const std::string& name, int* out) {
    std::string v;
    if (!prop_get(name, &v)) {
        return false;
    }
    *out = static_cast<int>(strtol(v.c_str(), nullptr, 0));
    return true;
}

static void load_config_from_properties() {
    /* 只认两个属性：
     *   mifod.path        要读的节点路径（不设 = 用 misf 的默认路径）
     *   mifod.input.device 要读的输入设备（设了就改用 /dev/input 触发）
     * 其余（EV_KEY / 任意 code / value=1 视为按下）全部写死。 */
    std::string v;
    if (prop_get(FP_PROP "path", &v) && !v.empty()) {
        if (v[0] == '/') {
            g_cfg.path = v;
        } else {
            ALOGW("%spath=\"%s\" 不是绝对路径，忽略（用默认 %s）", FP_PROP, v.c_str(),
                  g_cfg.path.c_str());
        }
    }
    if (prop_get(FP_PROP "input.device", &v) && !v.empty()) {
        g_cfg.input_device = v;
    }
    /* 通道：auto | hidl | aidl | none（默认 auto = misf 的探测顺序） */
    if (prop_get(FP_PROP "mode", &v) && !v.empty()) {
        if (v == "auto" || v == "hidl" || v == "aidl" || v == "none") {
            g_cfg.mode = v;
            g_cfg.mode_set = true;
            if (v == "aidl" || v == "hidl") {
                g_cfg.df_mode = v;          /* displayfeature 跟随 */
            }
            ALOGI("%smode=%s", FP_PROP, v.c_str());
        } else {
            ALOGW("%smode=\"%s\" 无效（auto|hidl|aidl|none），忽略", FP_PROP, v.c_str());
        }
    }

    if (prop_get_int(FP_PROP "extcmd.delay_ms", &g_cfg.sleep_ms)) {
        ALOGI("%sextcmd.delay_ms=%d（发 extCmd 前等待）", FP_PROP, g_cfg.sleep_ms);
    }
    if (prop_get(FP_PROP "prop", &v) && !v.empty()) {
        if (v == "true" || v == "1") {
            g_cfg.prop_trigger = "sys.fod.state";   /* 开关打开：固定读这个属性 */
        } else if (v == "false" || v == "0") {
            g_cfg.prop_trigger.clear();             /* 明确关闭：仍读节点 */
        } else {
            g_cfg.prop_trigger = v;                 /* 兼容：直接写属性名 */
        }
    }

    /* 可覆盖的输出参数（默认已是 misf 的值） */
    if (prop_get(FP_PROP "highlight.path", &v) && !v.empty()) {
        g_cfg.highlight_path = v;
    }
    prop_get_int(FP_PROP "highlight.value_on", &g_cfg.highlight_on);
    prop_get_int(FP_PROP "highlight.value_off", &g_cfg.highlight_off);
    prop_get_int(FP_PROP "extcmd.cmd", &g_cfg.cmd);
    prop_get_int(FP_PROP "extcmd.down", &g_cfg.down);
    prop_get_int(FP_PROP "extcmd.up", &g_cfg.up);


}

/* Configuration is always complete: every knob has a default.  This only
 * reports what is in effect so the log shows the truth. */
static const char* effective_trigger() {
    return "node";                  /* 触发源固定为 misf 的节点方式 */
}

static void log_effective_config() {
    const char* trig = effective_trigger();
    ALOGI("config: trigger=%s mode=%s cmd=%d guard=%d debug=%d", trig, g_cfg.mode.c_str(),
          static_cast<int>(g_cfg.cmd), g_cfg.guard ? 1 : 0, g_cfg.debug ? 1 : 0);
    if (!strcmp(trig, "node")) {
        ALOGI("config: path=%s path.param=\"%s\" down=%d up=%d (alt value=\"%s\" param=%d)"
              " poll=%dms", g_cfg.path.c_str(), g_cfg.path_param.c_str(), g_cfg.down, g_cfg.up,
              g_cfg.alt_value.c_str(), g_cfg.alt_param, g_cfg.poll_ms);
    } else if (!strcmp(trig, "timer")) {
        ALOGI("config: period_ms=%d timer.param=%d", g_cfg.period_ms, g_cfg.timer_param);
    } else if (!strcmp(trig, "prop")) {
        ALOGI("config: prop.name=%s prop.param=\"%s\" down=%d up=%d poll=%dms",
              g_cfg.prop_name.c_str(), g_cfg.prop_param.c_str(), g_cfg.down, g_cfg.up,
              g_cfg.poll_ms);
    }
}

/* -------------------------------------------------------- value comparison */

/*
 * Accepts "0x000E0000", "0xe0000", "917504" and "000E0000" (hex fallback).
 * Returns false for anything that is not a number at all.
 */
static bool parse_number(const std::string& s, long long* out) {
    if (s.empty()) {
        return false;
    }
    char* end = nullptr;
    errno = 0;
    long long v = strtoll(s.c_str(), &end, 0);
    if (errno == 0 && end != s.c_str() && *end == '\0') {
        *out = v;
        return true;
    }
    end = nullptr;
    errno = 0;
    v = strtoll(s.c_str(), &end, 16);
    if (errno == 0 && end != s.c_str() && *end == '\0') {
        *out = v;
        return true;
    }
    return false;
}

/*
 * mifod.path.param / mifod.alt.value are compared numerically against the node
 * value, so 0xe0000 == 0x000E0000 and 3 == 03; string compare otherwise.
 */
static bool value_matches(const std::string& value, const std::string& wanted) {
    long long v = 0, w = 0;
    if (parse_number(value, &v) && parse_number(wanted, &w)) {
        return v == w;
    }
    return value == wanted;
}

static bool value_is_press(const std::string& value) {
    return value_matches(value, g_cfg.path_param);
}


/* --------------------------------------------------------------- fault guard */

/*
 * A wrong HAL ABI (unknown ROM) must produce a log line, not a SIGSEGV and a
 * dead daemon.  The guarded region is one indirect call with POD arguments, so
 * siglongjmp() out of it cannot leak C++ objects.
 */
static sigjmp_buf g_fault_jmp;
static volatile sig_atomic_t g_in_guard = 0;
static bool g_guard_ready = false;

static void fault_handler(int sig, siginfo_t* /*info*/, void* /*ctx*/) {
    if (g_in_guard) {
        g_in_guard = 0;
        siglongjmp(g_fault_jmp, 1);
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static void install_fault_guard() {
    if (g_guard_ready) {
        return;
    }
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = fault_handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGBUS, &sa, nullptr);
    g_guard_ready = true;
}

/* ------------------------------------------------------------------ detection */

/*
 * The trigger node is opened once and read with pread(); when the kernel
 * supports notifications for it poll() wakes us the moment it changes, which
 * makes the reaction time ~0 instead of one poll period.  If poll() returns
 * immediately over and over without the value changing, notifications are not
 * supported and we fall back to sleeping poll_ms between reads.
 */
struct NodeSource {
    int fd = -1;
    bool poll_ok = true;
    int immediate = 0;
    bool warned_empty = false;
};

static NodeSource g_src;

static bool node_open() {
    if (g_src.fd >= 0) {
        return true;
    }
    int fd = open(g_cfg.path.c_str(), O_RDONLY | O_CLOEXEC | O_NONBLOCK);
    if (fd < 0) {
        return false;
    }
    g_src.fd = fd;
    g_src.poll_ok = true;
    g_src.immediate = 0;
    return true;
}

static void node_close() {
    if (g_src.fd >= 0) {
        close(g_src.fd);
        g_src.fd = -1;
    }
}

/* 1 = value in *out (may be empty), 0 = read failed (fd closed) */
static int node_read(std::string* out) {
    if (g_src.fd < 0) {
        return 0;
    }
    char buf[128] = {0};
    ssize_t n = pread(g_src.fd, buf, sizeof(buf) - 1, 0);
    if (n < 0) {
        int saved = errno;
        if (saved == ESPIPE) { /* seq_file style node: needs lseek */
            if (lseek(g_src.fd, 0, SEEK_SET) >= 0) {
                n = read(g_src.fd, buf, sizeof(buf) - 1);
                saved = errno;
            }
        }
        if (n < 0) {
            node_close();
            errno = saved;
            return 0;
        }
    }
    for (ssize_t i = n; i > 0; i--) {
        if (buf[i - 1] == '\n' || buf[i - 1] == '\r' || buf[i - 1] == ' ' || buf[i - 1] == '\t') {
            buf[i - 1] = '\0';
        } else {
            break;
        }
    }
    *out = buf;
    return 1;
}

/* Wait for a change (or the timeout).  Returns true if poll() reported one. */
/* poll_ms unset means "block until the node changes" (what misf does with
 * poll(fds, 1, -1)); the small delays below are only a fallback for descriptors
 * that cannot use poll() at all. */
static int poll_delay_ms() {
    return g_cfg.poll_ms > 0 ? g_cfg.poll_ms : 100;
}

static bool node_wait(int timeout_ms) {
    int wait_ms = timeout_ms > 0 ? timeout_ms : -1;
    if (g_cfg.debug && wait_ms < 0) {
        wait_ms = 30000;   /* heartbeat slice: proves it is parked in poll() */
    }
    if (g_src.fd < 0) {
        usleep(poll_delay_ms() * 1000);
        return false;
    }
    if (!g_src.poll_ok) {
        usleep(poll_delay_ms() * 1000);
        return false;
    }
    struct pollfd p = {g_src.fd, POLLPRI | POLLERR, 0};
    int64_t t0 = now_us();
    dbglog("[wait] poll(%s, %dms)", g_cfg.path.c_str(), wait_ms);
    int r = poll(&p, 1, wait_ms);
    dbglog("[wake] poll -> r=%d revents=%#x%s", r, p.revents,
           (r == 0 ? " (timeout: still parked, nothing changed)" : ""));
    int64_t dt = now_us() - t0;
    if (r > 0 && dt < 2000) {
        if (++g_src.immediate > 8) {
            g_src.poll_ok = false;
            ALOGI("%s does not support poll notifications; polling every %dms",
                  g_cfg.path.c_str(), g_cfg.poll_ms);
        }
    }
    return r > 0;
}

/*
 * Official FOD highlight control: MIUI's FodMonitorThread::setDisplayParam()
 * does fopen(path, "w") + fprintf("0x%x", value) on disp_param.  Same here.
 * Returns true when a value was written.
 */
static bool highlight_write(int32_t value) {
    if (!g_cfg.runtime_mode) {
        ALOGI("runtime.mode=false: 只观察，不写 %s", g_cfg.highlight_path.c_str());
        return false;
    }
    if (g_cfg.highlight_path.empty()) {
        return false;
    }
    int fd = open(g_cfg.highlight_path.c_str(), O_WRONLY | O_CLOEXEC);
    if (fd < 0) {
        ALOGW("highlight: cannot open %s: %s", g_cfg.highlight_path.c_str(), strerror(errno));
        return false;
    }
    char buf[32];
    int len = snprintf(buf, sizeof(buf), "0x%x", static_cast<unsigned>(value));
    ssize_t n = write(fd, buf, len);
    int saved = errno;
    close(fd);
    if (n != len) {
        ALOGW("highlight: write %s to %s failed: %s", buf, g_cfg.highlight_path.c_str(),
              strerror(saved));
        return false;
    }
    ALOGI("highlight: %s <- %s", g_cfg.highlight_path.c_str(), buf);
    return true;
}

/* ------------------------------------------------------------- node scanner */

/*
 * fp_monitor --scan[=dir1,dir2]
 *
 * Walks the given directories (default: the FOD/touch ones used by MIUI),
 * keeps every readable regular file open, and prints the ones whose content
 * changes.  Touch the sensor while it runs: the node that reacts is the trigger
 * this daemon should be pointed at.
 */
static void collect_files(const std::string& dir, int depth, std::vector<std::string>* out) {
    DIR* d = opendir(dir.c_str());
    if (d == nullptr) {
        return;
    }
    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        if (e->d_name[0] == '.') {
            continue;
        }
        std::string p = dir + "/" + e->d_name;
        struct stat st;
        if (stat(p.c_str(), &st) != 0) {
            continue;
        }
        if (S_ISDIR(st.st_mode)) {
            if (depth > 0) {
                collect_files(p, depth - 1, out);
            }
        } else if (S_ISREG(st.st_mode)) {
            if (access(p.c_str(), R_OK) == 0) {
                out->push_back(p);
            }
        }
    }
    closedir(d);
}

static std::string read_file(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NONBLOCK);
    if (fd < 0) {
        return "<open failed>";
    }
    char buf[256] = {0};
    ssize_t n = pread(fd, buf, sizeof(buf) - 1, 0);
    close(fd);
    if (n <= 0) {
        return "<empty>";
    }
    std::string s(buf, n);
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ')) {
        s.pop_back();
    }
    return s;
}

static int scan(const std::string& dirs_arg, int interval_ms) {
    std::vector<std::string> dirs;
    std::string cur;
    std::string arg = dirs_arg.empty()
            ? "/sys/class/drm,/sys/class/touch,/sys/class/touchscreen,/sys/class/leds"
            : dirs_arg;
    for (char c : arg) {
        if (c == ',') {
            if (!cur.empty()) dirs.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    if (!cur.empty()) {
        dirs.push_back(cur);
    }

    std::vector<std::string> files;
    for (const auto& d : dirs) {
        collect_files(d, 2, &files);
    }
    if (files.empty()) {
        ALOGE("scan: no readable files below the given directories");
        return 1;
    }
    ALOGI("scan: watching %zu files (%dms) -- touch the sensor now", files.size(), interval_ms);

    std::vector<std::string> values(files.size());
    for (size_t i = 0; i < files.size(); i++) {
        values[i] = read_file(files[i]);
    }
    int64_t t0 = now_us();
    while (true) {
        usleep(interval_ms * 1000);
        for (size_t i = 0; i < files.size(); i++) {
            std::string v = read_file(files[i]);
            if (v != values[i]) {
                ALOGI("CHANGED %+.3fs %s : \"%s\" -> \"%s\"",
                      (now_us() - t0) / 1000000.0, files[i].c_str(), values[i].c_str(), v.c_str());
                printf("CHANGED %+.3fs %s : \"%s\" -> \"%s\"\n", (now_us() - t0) / 1000000.0,
                       files[i].c_str(), values[i].c_str(), v.c_str());
                fflush(stdout);
                values[i] = v;
            }
        }
    }
    return 0;
}

/* ----------------------------------------------------------- HIDL back-end */

/* ------------------------------------------------ vendor interface libs
 * The vendor interface libraries are deliberately NOT linked (no DT_NEEDED on
 * /vendor/lib64): they are dlopen()ed by absolute path on first use, so the
 * binary runs from wherever it is dropped. */
static void* dlopen_vendor(const char* leaf) {
    std::string own_dir;
    char own[4096] = {0};
    ssize_t n = readlink("/proc/self/exe", own, sizeof(own) - 1);
    if (n > 0) {
        std::string p(own, static_cast<size_t>(n));
        size_t sl = p.rfind('/');
        if (sl != std::string::npos) {
            own_dir = p.substr(0, sl);
        }
    }
    const char* dirs[] = {"/vendor/lib64", "/system_ext/lib64", "/odm/lib64",
                          "/system/lib64", "/product/lib64"};
    std::string tried;
    for (const char* d : dirs) {
        std::string cand = std::string(d) + "/" + leaf;
        void* h = dlopen(cand.c_str(), RTLD_NOW | RTLD_GLOBAL);
        if (h != nullptr) {
            ALOGI("loaded %s", cand.c_str());
            return h;
        }
        tried += cand;
        tried += ' ';
    }
    if (!own_dir.empty()) {
        std::string cand = own_dir + "/" + leaf;
        void* h = dlopen(cand.c_str(), RTLD_NOW | RTLD_GLOBAL);
        if (h != nullptr) {
            ALOGI("loaded %s", cand.c_str());
            return h;
        }
        tried += cand;
        tried += ' ';
    }
    ALOGW("cannot load %s (tried: %s)", leaf, tried.c_str());
    return nullptr;
}

#define FP_HIDL_GETSERVICE_SYMBOL \
    "_ZN6vendor6xiaomi8hardware20fingerprintextension4V1_018IXiaomiFingerprint10getServiceERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEb"

/* getService() returns sp<T> BY VALUE.  sp<> is a non-trivial class, so the
 * AAPCS64 ABI returns it through a hidden pointer in x8 -- NOT as a normal first
 * argument.  Declaring it as `void (*)(void*, ...)` puts that pointer in x0 and
 * the callee writes the result to a garbage address (segfault).  Use the real
 * C++ signature so the compiler emits the correct ABI. */
typedef sp<IXiaomiFingerprint> (*FpGetServiceFn)(const std::string&, bool);

/* Minimal ABI stand-in for IDisplayFeature: we only need the returned sp<> to be
 * the right size/shape, never to call methods through this type. */
struct IDisplayFeatureStand : public ::android::RefBase {};
typedef sp<IDisplayFeatureStand> (*DfGetServiceFn)(const std::string&, bool);
extern void _fp_df_type_anchor(IDisplayFeatureStand*);   /* 仅防误用，不链接 */

static sp<IDisplayFeatureStand> g_df_sp;

static void* df_vendor_lib = nullptr;

static void* df_sym(const char* name) {
    if (df_vendor_lib == nullptr) {
        df_vendor_lib = dlopen_vendor("vendor.xiaomi.hardware.displayfeature@1.0.so");
    }
    return df_vendor_lib != nullptr ? dlsym(df_vendor_lib, name) : nullptr;
}

static sp<IXiaomiFingerprint> g_service;
static int g_hidl_slot = -1;

#ifdef FP_HAVE_HIDL_HEADER
#define FP_EXTCMD_SYMBOL nullptr /* compile-time dispatch, no dlsym needed */
#else
#define FP_EXTCMD_SYMBOL \
    "_ZN6vendor6xiaomi8hardware20fingerprintextension4V1_021BpHwXiaomiFingerprint6extCmdEjj"
#endif

/*
 * Find extCmd()'s vtable slot on the *actual* object.
 *
 * The vendor library exports its own proxy implementation
 * (BpHwXiaomiFingerprint::extCmd); when that address is present in the object's
 * vtable we know the slot without a hard-coded number.  On this device it is
 * slot 13 (byte offset 104), taken from the library's own generated server code
 * which dispatches the very same call:
 *
 *     ldr x8, [x0]        ; vptr
 *     ldr x9, [x8, #104]  ; vtable[13]
 *     blr x9
 *
 * (The vtable symbol has a 3 word negative prologue -- vcall offset,
 * offset-to-top, typeinfo -- which is why "last virtual" != "last word".)
 */
static int resolve_hidl_slot(IXiaomiFingerprint* service) {
    void** vptr = *reinterpret_cast<void***>(service);
    if (vptr == nullptr) {
        return -1;
    }
#ifdef FP_HAVE_HIDL_HEADER
    return -1; /* compile-time dispatch on this path */
#else
    void* direct = dlsym(RTLD_DEFAULT, FP_EXTCMD_SYMBOL);
    if (direct != nullptr) {
        for (int i = 0; i < 64; i++) {
            if (vptr[i] == direct) {
                return i;
            }
        }
    }
    if (g_cfg.hidl_slot > 0) {
        return g_cfg.hidl_slot;
    }
    return kIXiaomiFingerprint_ExtCmdSlot;
#endif
}

static bool hidl_connect() {
    if (g_service != nullptr) {
        return true;
    }
    static void* fp_lib = nullptr;
    if (fp_lib == nullptr) {
        fp_lib = dlopen_vendor("vendor.xiaomi.hardware.fingerprintextension@1.0.so");
    }
    if (fp_lib == nullptr) {
        return false;
    }
    auto get_service = reinterpret_cast<FpGetServiceFn>(
            dlsym(fp_lib, FP_HIDL_GETSERVICE_SYMBOL));
    if (get_service == nullptr) {
        ALOGE("fingerprintextension: getService symbol not found in the library");
        return false;
    }
    g_service = get_service(g_cfg.hidl_instance, false);
    if (g_service == nullptr) {
        ALOGW("getService(\"%s\") returned null", g_cfg.hidl_instance.c_str());
        return false;
    }
    ALOGI("connected: %s", "vendor.xiaomi.hardware.fingerprintextension@1.0::IXiaomiFingerprint");
#ifndef FP_HAVE_HIDL_HEADER
    g_hidl_slot = resolve_hidl_slot(g_service.get());
    if (g_hidl_slot < 0) {
        ALOGE("cannot determine extCmd vtable slot");
        g_service = nullptr;
        return false;
    }
    void* direct = dlsym(RTLD_DEFAULT, FP_EXTCMD_SYMBOL);
    ALOGI("extCmd: vtable slot %d (byte %d), direct symbol %p%s", g_hidl_slot, g_hidl_slot * 8,
          direct, direct == nullptr ? " (not exported: using configured slot)" : "");
    if (g_cfg.hidl_slot > 0 && g_hidl_slot != g_cfg.hidl_slot) {
        ALOGW("configured slot=%d but auto-detected slot=%d; using the detected one",
              g_cfg.hidl_slot, g_hidl_slot);
    }
#endif
    return true;
}

/* Returns: 1 = call done, 0 = transport error, -1 = process fault (ABI mismatch) */
static int hidl_call(int32_t param, int32_t* result) {
    if (g_service == nullptr) {
        return 0;
    }
#ifdef FP_HAVE_HIDL_HEADER
    Return<int32_t> ret = g_service->extCmd(g_cfg.cmd, param);
    if (!ret.isOk()) {
        return 0;
    }
    *result = static_cast<int32_t>(ret);
    return 1;
#else
    void** vptr = *reinterpret_cast<void***>(g_service.get());
    if (vptr == nullptr || g_hidl_slot < 0) {
        return 0;
    }
    typedef Return<int32_t> (*ExtCmdFn)(void*, int32_t, int32_t);
    ExtCmdFn fn = reinterpret_cast<ExtCmdFn>(vptr[g_hidl_slot]);
    if (fn == nullptr) {
        return 0;
    }
    if (g_cfg.guard && g_guard_ready) {
        if (sigsetjmp(g_fault_jmp, 1) != 0) {
            return -1;
        }
        g_in_guard = 1;
        Return<int32_t> ret = fn(g_service.get(), g_cfg.cmd, param);
        g_in_guard = 0;
        if (!ret.isOk()) {
            return 0;
        }
        *result = static_cast<int32_t>(ret);
        return 1;
    }
    Return<int32_t> ret = fn(g_service.get(), g_cfg.cmd, param);
    if (!ret.isOk()) {
        return 0;
    }
    *result = static_cast<int32_t>(ret);
    return 1;
#endif
}

/* ------------------------------------ vendor.xiaomi.hardware.displayfeature
 *
 * misf's FodMonitorThread does TWO HAL calls, not one:
 *   - FingerprintStateManager::sendCmd(10, 1|6|0)  -> extCmd  (implemented above)
 *   - DisplayFeatureIntf::setFeature(0, 24, 1|0, 0) -> the displayfeature HAL
 * The second one is what actually tells the display stack "FOD capture on/off"
 * (caseId 24).  Both the HIDL and the AIDL interface libraries export their
 * whole client side, so we call the generated client methods directly:
 *   HIDL: BpHwDisplayFeature::setFeature(int,int,int,int)
 *   AIDL: BpDisplayFeature::setFeature(int,int,int,int)   (transact code 7)
 */
extern "C" {
void _ZN6vendor6xiaomi8hardware14displayfeature4V1_015IDisplayFeature10getServiceERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEb(
        void* ret_sp, const std::string* name, bool getStub);
void _ZN6vendor6xiaomi8hardware14displayfeature4V1_018BpHwDisplayFeature10setFeatureEiiii(
        void* self, int32_t displayId, int32_t caseId, int32_t modeId, int32_t cookie);
}
#define DF_HIDL_GETSERVICE_SYMBOL \
    "_ZN6vendor6xiaomi8hardware14displayfeature4V1_015IDisplayFeature10getServiceERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEb"
#define DF_HIDL_SETFEATURE_SYMBOL \
    "_ZN6vendor6xiaomi8hardware14displayfeature4V1_018BpHwDisplayFeature10setFeatureEiiii"
#define DF_HIDL_SETFEATURE(self, d, c, m, k)                                                \
    do {                                                                                    \
        auto f = reinterpret_cast<Return<void> (*)(void*, int32_t, int32_t, int32_t,       \
                                                   int32_t)>(df_sym(DF_HIDL_SETFEATURE_SYMBOL)); \
        if (f == nullptr) {                                                                 \
            ALOGW("displayfeature: setFeature symbol not found in the library");            \
        } else {                                                                            \
            f((self), (d), (c), (m), (k));  /* real Return<void> ABI */                     \
        }                                                                                   \
    } while (0)
#define DF_HIDL_DESCRIPTOR "vendor.xiaomi.hardware.displayfeature@1.0::IDisplayFeature"

/* ------------------------------------------------------------ AIDL back-end */

/*
 * Generic AIDL client: the interface is looked up in servicemanager and the
 * method is issued as a raw transaction, so no generated AIDL code is needed.
 * The method is assumed to be `int extCmd(int cmd, int param)`, the shape of
 * every known Xiaomi fingerprint extension interface.
 */
#if defined(__has_include)
#if __has_include(<android/binder_manager.h>)
#include <android/binder_manager.h>
#define FP_HAVE_BINDER_MANAGER_HEADER 1
#endif
#if __has_include(<android/binder_ibinder.h>) && __has_include(<android/binder_parcel.h>)
#include <android/binder_ibinder.h>
#include <android/binder_parcel.h>
#define FP_HAVE_BINDER_NDK_HEADERS 1
#endif
#endif

#ifndef FP_HAVE_BINDER_NDK_HEADERS
#define FP_HAVE_BINDER_NDK_HEADERS 0
#endif

#if !FP_HAVE_BINDER_NDK_HEADERS
typedef struct AIBinder AIBinder;
#endif

#if !FP_HAVE_BINDER_MANAGER_HEADER && FP_HAVE_BINDER_NDK_HEADERS
extern "C" AIBinder* AServiceManager_getService(const char* instance);
#endif

static AIBinder* g_aidl_binder = nullptr;

static bool aidl_connect() {
    if (g_aidl_binder != nullptr) {
        return true;
    }
    if (!FP_HAVE_BINDER_NDK_HEADERS) {
        ALOGE("built without libbinder_ndk headers, aidl backend unavailable");
        return false;
    }
    g_aidl_binder = AServiceManager_getService(g_cfg.aidl_iface.c_str());
    if (g_aidl_binder == nullptr) {
        ALOGW("AServiceManager_getService(\"%s\") returned null", g_cfg.aidl_iface.c_str());
        return false;
    }
    ALOGI("connected: %s", g_cfg.aidl_iface.c_str());
    return true;
}

/* Returns: 1 = call done, 0 = transport error, -1 = process fault */
static int aidl_call(int32_t param, int32_t* result) {
#if !FP_HAVE_BINDER_NDK_HEADERS
    (void)param;
    (void)result;
    return 0;
#else
    if (g_aidl_binder == nullptr) {
        return 0;
    }
    if (g_cfg.guard && g_guard_ready) {
        if (sigsetjmp(g_fault_jmp, 1) != 0) {
            return -1;
        }
        g_in_guard = 1;
    }
    int rc = 0;
    AParcel* data = nullptr;
    AParcel* reply = nullptr;
    AStatus* status = nullptr;
    binder_status_t st;
    do {
        st = AIBinder_prepareTransaction(g_aidl_binder, &data);
        if (st != STATUS_OK) {
            ALOGE("aidl: prepareTransaction failed: %d%s", st,
                  st == STATUS_INVALID_OPERATION
                          ? " (STATUS_INVALID_OPERATION = the service reports no interface"
                            " descriptor, i.e. it is not an AIDL-NDK service -- on this ROM"
                            " the extension is probably HIDL-only, use mifod.mode=hidl)"
                          : "");
            break;
        }
        st = AParcel_writeInt32(data, g_cfg.cmd);
        if (st != STATUS_OK) { ALOGE("aidl: write cmd(%d) failed: %d", g_cfg.cmd, st); break; }
        st = AParcel_writeInt32(data, param);
        if (st != STATUS_OK) { ALOGE("aidl: write param(%d) failed: %d", param, st); break; }
        st = AIBinder_transact(g_aidl_binder, g_cfg.aidl_code, &data, &reply, 0);
        if (st != STATUS_OK) {
            ALOGE("aidl: transact code=%d failed: %d%s", g_cfg.aidl_code, st,
                  st == -74 ? " (STATUS_FDS_NOT_ALLOWED: see binder_status.h; the ROM may"
                              " reject the transaction from this context)" : "");
            break;
        }
        if (reply == nullptr) { ALOGE("aidl: no reply parcel"); break; }
        /* AIDL replies begin with the status header (AStatus); the out parameter
         * follows it.  Reading the int straight away would return the status,
         * never the value -- and would hide service exceptions. */
        st = AParcel_readStatusHeader(reply, &status);
        if (st != STATUS_OK) { ALOGE("aidl: readStatusHeader failed: %d", st); break; }
        if (!AStatus_isOk(status)) {
            const char* msg = AStatus_getMessage(status);
            ALOGE("aidl: service exception code=%d%s%s", AStatus_getExceptionCode(status),
                  msg != nullptr ? " msg=" : "", msg != nullptr ? msg : "");
            break;
        }
        st = AParcel_readInt32(reply, result);
        if (st != STATUS_OK) { ALOGE("aidl: read out parameter failed: %d", st); break; }
        rc = 1;
    } while (false);
    if (status != nullptr) {
        AStatus_delete(status);
    }
    if (data != nullptr) {
        AParcel_delete(data);
    }
    if (reply != nullptr) {
        AParcel_delete(reply);
    }
    if (g_cfg.guard && g_guard_ready) {
        g_in_guard = 0;
    }
    return rc;
#endif
}

/* ------------------------------------------------------------------ dispatch */

/* --------------------------------------------------------- displayfeature */
static void* g_df_service = nullptr;
static bool g_df_tried = false;
static bool g_df_ok = false;

static bool df_connect() {
    if (g_df_ok) {
        return true;
    }
    if (g_df_tried) {
        return false;
    }
    g_df_tried = true;
    if (g_cfg.df_mode.empty() || g_cfg.df_mode == "none") {
        ALOGW("skip displayfeature: %sdf.mode is not set", FP_PROP);
        return false;
    }
    if (g_cfg.df_mode == "aidl") {
        g_df_service = AServiceManager_getService(g_cfg.df_aidl_iface.c_str());
        if (g_df_service == nullptr) {
            ALOGW("displayfeature: AIDL getService(\"%s\") returned null",
                  g_cfg.df_aidl_iface.c_str());
            return false;
        }
        g_df_ok = true;
        ALOGI("displayfeature: AIDL connected: %s", g_cfg.df_aidl_iface.c_str());
        return true;
    }
    if (g_cfg.df_mode != "hidl") {
        ALOGE("displayfeature: unknown %sdf.mode=\"%s\" (hidl | aidl | none)", FP_PROP,
              g_cfg.df_mode.c_str());
        return false;
    }
    std::string inst = g_cfg.df_instance;
    auto df_get_service = reinterpret_cast<DfGetServiceFn>(
            df_sym(DF_HIDL_GETSERVICE_SYMBOL));
    if (df_get_service == nullptr) {
        ALOGW("displayfeature: getService symbol not found in the library");
        return false;
    }
    g_df_sp = df_get_service(inst, false);
    g_df_service = g_df_sp.get();
    if (g_df_service == nullptr) {
        ALOGW("displayfeature: HIDL getService(\"%s\") returned null (is the service "
              "running? try %sdf.mode=aidl)", inst.c_str(), FP_PROP);
        return false;
    }
    g_df_ok = true;
    ALOGI("displayfeature: HIDL connected: %s instance=%s (%p)", DF_HIDL_DESCRIPTOR,
          inst.c_str(), g_df_service);
    return true;
}

/* int,int,int,int -> void; returns 1 when the call went out */
static int df_setfeature_vals(int32_t displayId, int32_t caseId, int32_t modeId,
                              int32_t cookie) {
    if (!g_cfg.runtime_mode) {
        ALOGI("runtime.mode=false: 只观察，不调 displayfeature");
        return 0;
    }
    dbglog("[df] setFeature(displayId=%d, caseId=%d, modeId=%d, cookie=%d) mode=%s", displayId,
           caseId, modeId, cookie, g_cfg.df_mode.c_str());
    if (!g_cfg.df_enable) {
        return 0;
    }
    if (!df_connect()) {
        return 0;
    }
    if (g_cfg.df_mode == "aidl") {
        AParcel* data = nullptr;
        AParcel* reply = nullptr;
        AStatus* status = nullptr;
        binder_status_t st = AIBinder_prepareTransaction(static_cast<AIBinder*>(g_df_service), &data);
        if (st != STATUS_OK) {
            ALOGE("displayfeature: prepareTransaction failed: %d%s", st,
                  st == STATUS_INVALID_OPERATION
                          ? " (service reports no interface descriptor -- not an AIDL service?)"
                          : "");
            return 0;
        }
        if (AParcel_writeInt32(data, displayId) != STATUS_OK ||
            AParcel_writeInt32(data, caseId) != STATUS_OK ||
            AParcel_writeInt32(data, modeId) != STATUS_OK ||
            AParcel_writeInt32(data, cookie) != STATUS_OK) {
            ALOGE("displayfeature: write failed");
            AParcel_delete(data);
            return 0;
        }
        st = AIBinder_transact(static_cast<AIBinder*>(g_df_service), g_cfg.df_aidl_code, &data, &reply, 0);
        if (st != STATUS_OK) {
            ALOGE("displayfeature: transact code=%d failed: %d", g_cfg.df_aidl_code, st);
            if (data) AParcel_delete(data);
            if (reply) AParcel_delete(reply);
            return 0;
        }
        if (reply != nullptr) {
            if (AParcel_readStatusHeader(reply, &status) == STATUS_OK && !AStatus_isOk(status)) {
                const char* msg = AStatus_getMessage(status);
                ALOGE("displayfeature: exception code=%d%s%s", AStatus_getExceptionCode(status),
                      msg ? " msg=" : "", msg ? msg : "");
                if (status) AStatus_delete(status);
                if (data) AParcel_delete(data);
                if (reply) AParcel_delete(reply);
                return 0;
            }
            if (status) AStatus_delete(status);
            AParcel_delete(reply);
        }
        if (data) AParcel_delete(data);
    } else {
        DF_HIDL_SETFEATURE(g_df_service, displayId, caseId, modeId, cookie);
    }
    ALOGI("displayfeature setFeature(displayId=%d, caseId=%d, modeId=%d, cookie=%d)",
          displayId, caseId, modeId, cookie);
    return 1;
}

static void df_fod(int on) {
    if (!g_cfg.df_case_set) {
        static bool warned = false;
        if (!warned) {
            warned = true;
            ALOGI("skip displayfeature: %sdf.case is not set", FP_PROP);
        }
        return;
    }
    if (on && !g_cfg.df_on_set) {
        return;
    }
    if (!on && !g_cfg.df_off_set) {
        return;
    }
    df_setfeature_vals(0, g_cfg.df_case, on ? g_cfg.df_on : g_cfg.df_off, g_cfg.df_cookie);
}

static bool g_backend_broken = false;

static volatile sig_atomic_t g_stop = 0;
static void fp_on_signal(int) { g_stop = 1; }

static void backend_resolve_auto() {
    if (g_cfg.mode != "auto") {
        return;
    }
    if (aidl_connect()) {          /* misf: AIDL 优先 */
        g_cfg.mode = "aidl";
        ALOGI("auto: using AIDL (like misf)");
        return;
    }
    if (hidl_connect()) {          /* 回退 HIDL */
        g_cfg.mode = "hidl";
        ALOGI("auto: using HIDL (like misf)");
        return;
    }
    static bool warned = false;
    if (!warned) {
        warned = true;
        ALOGW("mode=auto: no fingerprint-extension backend available yet -- retrying silently");
    }
}

static void backend_send(int32_t param) {
    if (!g_cfg.runtime_mode) {
        ALOGI("runtime.mode=false: 只观察，不发 extCmd(%d, %d)",
              static_cast<int>(g_cfg.cmd), static_cast<int>(param));
        return;
    }
    backend_resolve_auto();
    dbglog("[hal] extCmd(%d, %d) via %s", static_cast<int>(g_cfg.cmd), static_cast<int>(param),
           g_cfg.mode.c_str());
    if (g_cfg.mode == "none") {
        ALOGI("mode=none: would call extCmd(%d, %d)", static_cast<int>(g_cfg.cmd),
              static_cast<int>(param));
        return;
    }
    if (g_backend_broken) {
        return;
    }
    bool connected = (g_cfg.mode == "aidl") ? aidl_connect() : hidl_connect();
    if (!connected) {
        return;
    }
    int32_t result = 0;
    int rc = (g_cfg.mode == "aidl") ? aidl_call(param, &result) : hidl_call(param, &result);

    if (rc == -1) {
        g_backend_broken = true;
        ALOGE("FATAL: the %s call faulted (bad vtable slot / ABI mismatch). HAL disabled, still "
              "watching %s. Set %smode none to silence, or fix %sslot.",
              g_cfg.mode.c_str(), g_cfg.path.c_str(), FP_PROP, FP_PROP);
        return;
    }
    if (rc == 0) {
        ALOGW("extCmd(%d, %d) failed on %s backend -- will reconnect", static_cast<int>(g_cfg.cmd),
              static_cast<int>(param), g_cfg.mode.c_str());
        g_service = nullptr;
        g_aidl_binder = nullptr;
        return;
    }
    dbglog("[hal] extCmd(%d, %d) -> %d (rc=%d)", static_cast<int>(g_cfg.cmd),
           static_cast<int>(param), static_cast<int>(result), rc);
    ALOGI("extCmd(%d, %d) -> %d", static_cast<int>(g_cfg.cmd), static_cast<int>(param),
          static_cast<int>(result));
}

/*
 * Faithful port of MIUI FodMonitorThread::threadLoop():
 *
 *     v = strtoul(fod_ui_ready, NULL, 10);
 *     if (v == 3)      { setFeature(0,24,1,0); "fod capture start"; usleep(mSleepMs); sendCmd(10, 1); mFodCapture = true; }
 *     else if (v == 7) {                       "fod capture start"; usleep(mSleepMs); sendCmd(10, 6); mFodCapture = true; }
 *     else             { if (!mFodCapture) return; setFeature(0,24,0,0); "fod capture stop"; sendCmd(10, 0); mFodCapture = false; }
 *
 * mifod.path.param is the first value (3 above), mifod.alt.value/param the
 * second one (7 -> 6), mifod.up the "everything else" parameter (0) and
 * mifod.sleep_ms the mSleepMs delay.  mifod.highlight.* is not part of misf;
 * it exists only for ROMs where nothing else lights the panel.
 */
static bool g_fod_capture = false;

static void on_value(const std::string& value) {
    bool first = !value.empty() && value_matches(value, g_cfg.path_param);
    if (first || g_fod_capture) {
        dbglog("[act] value=\"%s\" first=%d alt=%d capture=%d down_set=%d up_set=%d",
               value.c_str(), first ? 1 : 0, 0, g_fod_capture ? 1 : 0,
               g_cfg.down_set ? 1 : 0, g_cfg.up_set ? 1 : 0);
    }

    if (first) {
        /* misf re-sends the start command whenever it sees 3/7 again -- no guard.
         * misf also calls DisplayFeatureIntf::setFeature(0,24,1,0) first on the
         * "ready" value only (not on the alt value).
         * Every action below runs only when its parameter was configured: a
         * property that was never set means "skip this step", never a guess. */
        if (first) {
            df_fod(1);
        }
        if (g_cfg.highlight_on_set) {
            highlight_write(g_cfg.highlight_on);
        }
        if (g_cfg.sleep_ms > 0) {
            usleep(g_cfg.sleep_ms * 1000);
        }
        if (first) {
            if (g_cfg.down_set) {
                backend_send(g_cfg.down);
            } else {
                ALOGI("skip %sdown (not set): no extCmd on finger-down", FP_PROP);
            }
        } else if (false) {
            backend_send(g_cfg.alt_param);
        } else {
            ALOGI("skip %salt.param (not set): no extCmd for value \"%s\"", FP_PROP,
                  g_cfg.alt_value.c_str());
        }
        g_fod_capture = true;
        return;
    }

    if (!g_fod_capture) {
        return; /* misf: nothing to stop */
    }
    df_fod(0);
    if (g_cfg.up_set) {
        backend_send(g_cfg.up);
    } else {
        ALOGI("skip %sup (not set): no extCmd on finger-up", FP_PROP);
    }
    if (g_cfg.highlight_off_set) {
        highlight_write(g_cfg.highlight_off);
    }
    g_fod_capture = false;
}

/* ---------------------------------------------------------------- CLI/probe */

static void usage(const char* argv0) {
    fprintf(stderr,
        "usage: %s [options]\n\n"
        "默认行为 = misf 的 1:1 复刻（不需要设置任何属性）：\n"
        "  读 /sys/class/drm/card0-DSI-1/fod_ui_ready（阻塞等待变化）\n"
        "    读到 3  -> setFeature(0,24,1,0) + disp_param=0x70000 + extCmd(10, 1)\n"
        "    读到 7  -> disp_param=0x70000 + extCmd(10, 6)（不调 displayfeature）\n"
        "    其它值（且已 start） -> setFeature(0,24,0,0) + extCmd(10, 0) + disp_param=0x80000\n"
        "  通道：AIDL 优先 → HIDL 回退（运行期探测，同 misf）\n"
        "  动作只在值变化时执行一次；只有 start 过才发 stop\n\n"
        "可设置的属性（不设 = 用 misf 的默认值）：\n"
        "  mifod.mode                  hidl | aidl | auto（默认 auto）\n"
        "  mifod.path                  节点路径；非绝对路径会被忽略\n"
        "  mifod.extcmd.cmd            10\n"
        "  mifod.extcmd.down           1\n"
        "  mifod.extcmd.up             0\n"
        "  mifod.highlight.path        /sys/class/drm/card0-DSI-1/disp_param\n"
        "  mifod.highlight.value_on    0x70000\n"
        "  mifod.highlight.value_off   0x80000\n"
        "  mifod.input.device          设置后改用 /dev/input 触发（设备名或 /dev/input/eventN）\n"
        "  mifod.input.type            0 = 任意类型（忽略 EV_SYN），1 = EV_KEY\n"
        "  mifod.input.code            0 = 任意 code\n"
        "  mifod.input.value_down      1\n\n"
        "命令行（与属性等价、优先级更高；以下这些仅命令行可用）：\n"
        "  --mode=  --path=  --path-param=  --cmd=  --down=  --up=  --alt-value=  --alt-param=\n"
        "  --highlight-path=  --highlight-on=  --highlight-off=  --poll-ms=  --sleep-ms=\n"
        "  --slot=  --instance=  --aidl-iface=  --aidl-code=\n"
        "  --df-mode=  --df-case=  --df-on=  --df-off=  --df-cookie=  --df-disable\n"
        "  --guard=  --debug | -v\n\n"
        "一次性动作：\n"
        "  --probe                          打印节点值 / 生效配置 / HAL 状态后退出\n"
        "  --scan[=DIR1,DIR2]               扫描可读节点，打印哪些会变化\n"
        "  --scan-input[=DEVICE]            打印 /dev/input 的真实事件（type/code/value），5 秒\n"
        "  --write=VALUE                    往 mifod.highlight.path 写一次\n"
        "  --extcmd=CMD[,PARAM]             只发一次 extCmd（复位：--extcmd=10,0）\n"
        "  --setfeature=CASE,MODE[,COOKIE]  只调一次 displayfeature（复位：--setfeature=24,0）\n"
        "  --once                           一次检测 + 一次 HAL 往返\n"
        "  --dry-run                        不调用 HAL，只打日志\n"
        "  --help\n",
        argv0);
}

static bool arg_value(const char* arg, const char* name, const char** out) {
    size_t len = strlen(name);
    if (strncmp(arg, name, len) != 0) {
        return false;
    }
    if (arg[len] == '=') {
        *out = arg + len + 1;
        return true;
    }
    return arg[len] == '\0' ? (*out = "", true) : false;
}

static int probe() {
    if (g_cfg.path_set) {
        node_open();
    }
    std::string raw;
    bool ok = g_cfg.path_set && node_open() && node_read(&raw) == 1;
    bool state = ok && !raw.empty() && value_is_press(raw);

    printf("path      : %s%s\n", g_cfg.path_set ? g_cfg.path.c_str() : "<not set>",
           g_cfg.path_set ? "" : "   (setprop " FP_PROP "path ...)");
    printf("path.param: %s%s\n", g_cfg.path_param_set ? g_cfg.path_param.c_str() : "<not set>",
           g_cfg.path_param_set ? "" : "   (setprop " FP_PROP "path.param ...)");
    printf("value     : %s%s\n", ok ? ("\"" + raw + "\"").c_str() : "<unreadable>",
           ok ? (raw.empty() ? "  -> EMPTY (write-only node? try --scan)" : (state ? "  -> active" : "  -> idle")) : "");
    printf("mode      : %s%s   cmd=%s%s   down=%s   up=%s\n",
           g_cfg.mode_set ? g_cfg.mode.c_str() : "<not set>",
           g_cfg.mode_set ? "" : "   (setprop " FP_PROP "mode hidl)",
           g_cfg.cmd_set ? std::to_string(g_cfg.cmd).c_str() : "<not set>",
           g_cfg.cmd_set ? "" : "   (setprop " FP_PROP "cmd 10)",
           g_cfg.down_set ? std::to_string(g_cfg.down).c_str() : "<not set>",
           g_cfg.up_set ? std::to_string(g_cfg.up).c_str() : "<not set>");
    if (!g_cfg.alt_value.empty()) {
        printf("alt       : value %s -> extCmd(%d, %d)\n", g_cfg.alt_value.c_str(),
               static_cast<int>(g_cfg.cmd), static_cast<int>(g_cfg.alt_param));
    }
    if (g_cfg.sleep_ms) {
        printf("sleep     : %dms before extCmd\n", g_cfg.sleep_ms);
    }
    printf("highlight : %s", g_cfg.highlight_path.empty() ? "<disabled>" : g_cfg.highlight_path.c_str());
    if (!g_cfg.alt_value.empty()) {
        ALOGI("config: alt value %s -> extCmd(%d, %d)", g_cfg.alt_value.c_str(),
              static_cast<int>(g_cfg.cmd), static_cast<int>(g_cfg.alt_param));
    }
    if (g_cfg.sleep_ms) {
        ALOGI("config: sleep %dms before extCmd (misf mSleepMs)", g_cfg.sleep_ms);
    }
    if (!g_cfg.highlight_path.empty()) {
        printf("  on=0x%x off=0x%x", static_cast<unsigned>(g_cfg.highlight_on),
               static_cast<unsigned>(g_cfg.highlight_off));
    }
    printf("\n");

    if (g_cfg.mode_set && g_cfg.mode == "hidl") {
        bool connected = hidl_connect();
        printf("hidl      : instance=%s connected=%s\n", g_cfg.hidl_instance.c_str(),
               connected ? "yes" : "no");
#ifndef FP_HAVE_HIDL_HEADER
        void* direct = dlsym(RTLD_DEFAULT, FP_EXTCMD_SYMBOL);
        printf("            exported extCmd symbol: %s\n",
               direct ? "found" : "NOT found (will use configured slot)");
        if (connected) {
            void** vptr = *reinterpret_cast<void***>(g_service.get());
            int found = -1;
            for (int i = 0; direct != nullptr && i < 64; i++) {
                if (vptr[i] == direct) {
                    found = i;
                    break;
                }
            }
            printf("            vtable slot: %d%s\n",
                   found >= 0 ? found : resolve_hidl_slot(g_service.get()),
                   found >= 0 ? " (auto-detected)" : " (configured/default)");
        }
#endif
    } else if (g_cfg.mode_set && g_cfg.mode == "aidl") {
        printf("aidl      : iface=%s code=%d connected=%s\n", g_cfg.aidl_iface.c_str(),
               g_cfg.aidl_code, aidl_connect() ? "yes" : "no");
    }
    return 0;
}

/* --------------------------------------------------------------------- main */

int main(int argc, char** argv) {
    load_config_from_properties();

    bool dry_run = false;
    bool once = false;
    bool do_probe = false;
    bool scan_input = false;
    bool do_scan = false;
    bool do_setfeature = false;
    bool do_extcmd = false;
    int32_t extcmd_cmd = 0, extcmd_param = 0;
    int setf_case = g_cfg.df_case, setf_mode = g_cfg.df_on, setf_cookie = g_cfg.df_cookie;
    bool have_write = false;
    int32_t write_value = 0;
    std::string scan_dirs;

    for (int i = 1; i < argc; i++) {
        const char* v = nullptr;
        if (strcmp(argv[i], "--help") == 0) {
            usage(argv[0]);
            return 0;
        } else if (strcmp(argv[i], "--probe") == 0) {
            do_probe = true;
        } else if (arg_value(argv[i], "--scan-input", &v)) {
            scan_input = true;
            if (v != nullptr && *v != '\0') g_cfg.input_device = v;
        } else if (strcmp(argv[i], "--scan") == 0) {
            do_scan = true;
        } else if (arg_value(argv[i], "--scan", &v)) {
            do_scan = true;
            scan_dirs = v;
        } else if (strcmp(argv[i], "--once") == 0) {
            once = true;
        } else if (strcmp(argv[i], "--dry-run") == 0) {
            dry_run = true;
            g_cfg.mode = "none";
            g_cfg.mode_set = true;
        } else if (arg_value(argv[i], "--path", &v)) {
            g_cfg.path = v;
            g_cfg.path_set = true;
        } else if (arg_value(argv[i], "--path-param", &v)) {
            g_cfg.path_param = v;
            g_cfg.path_param_set = true;
        } else if (arg_value(argv[i], "--down", &v)) {
            g_cfg.down = static_cast<int32_t>(strtol(v, nullptr, 0));
            g_cfg.down_set = true;
        } else if (arg_value(argv[i], "--up", &v)) {
            g_cfg.up = static_cast<int32_t>(strtol(v, nullptr, 0));
            g_cfg.up_set = true;
        } else if (arg_value(argv[i], "--mode", &v)) {
            g_cfg.mode = v;
            g_cfg.mode_set = true;
        } else if (arg_value(argv[i], "--cmd", &v)) {
            g_cfg.cmd = static_cast<int32_t>(strtol(v, nullptr, 0));
            g_cfg.cmd_set = true;
        } else if (arg_value(argv[i], "--alt-value", &v)) {
            g_cfg.alt_value = v;
        } else if (arg_value(argv[i], "--alt-param", &v)) {
            g_cfg.alt_param = static_cast<int32_t>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--sleep-ms", &v)) {
            g_cfg.sleep_ms = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--write", &v)) {
            write_value = static_cast<int32_t>(strtol(v, nullptr, 0));
            have_write = true;
        } else if (arg_value(argv[i], "--highlight-path", &v)) {
            g_cfg.highlight_path = v;
        } else if (arg_value(argv[i], "--highlight-on", &v)) {
            g_cfg.highlight_on = static_cast<int32_t>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--highlight-off", &v)) {
            g_cfg.highlight_off = static_cast<int32_t>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--poll-ms", &v)) {
            g_cfg.poll_ms = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--slot", &v)) {
            g_cfg.hidl_slot = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--instance", &v)) {
            g_cfg.hidl_instance = v;
        } else if (arg_value(argv[i], "--aidl-iface", &v)) {
            g_cfg.aidl_iface = v;
        } else if (arg_value(argv[i], "--aidl-code", &v)) {
        } else if (arg_value(argv[i], "--trigger", &v)) {
            g_cfg.trigger = v;
        } else if (arg_value(argv[i], "--period-ms", &v)) {
            g_cfg.period_ms = static_cast<int>(strtol(v, nullptr, 0));
            g_cfg.period_set = true;
        } else if (arg_value(argv[i], "--timer-param", &v)) {
            g_cfg.timer_param = static_cast<int>(strtol(v, nullptr, 0));
            g_cfg.timer_param_set = true;
        } else if (arg_value(argv[i], "--prop-name", &v)) {
            g_cfg.prop_name = v;
            g_cfg.prop_name_set = !g_cfg.prop_name.empty();
        } else if (arg_value(argv[i], "--prop-param", &v)) {
        } else if (arg_value(argv[i], "--df-mode", &v)) {
            g_cfg.df_mode = v;
        } else if (arg_value(argv[i], "--df-instance", &v)) {
            g_cfg.df_instance = v;
        } else if (arg_value(argv[i], "--df-aidl-iface", &v)) {
            g_cfg.df_aidl_iface = v;
        } else if (arg_value(argv[i], "--df-aidl-code", &v)) {
            g_cfg.df_aidl_code = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--df-case", &v)) {
            g_cfg.df_case = static_cast<int>(strtol(v, nullptr, 0));
            g_cfg.df_case_set = true;
        } else if (arg_value(argv[i], "--df-on", &v)) {
            g_cfg.df_on = static_cast<int>(strtol(v, nullptr, 0));
            g_cfg.df_on_set = true;
        } else if (arg_value(argv[i], "--df-off", &v)) {
            g_cfg.df_off = static_cast<int>(strtol(v, nullptr, 0));
            g_cfg.df_off_set = true;
        } else if (arg_value(argv[i], "--df-cookie", &v)) {
            g_cfg.df_cookie = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--debug", &v)) {
            g_cfg.debug = strtol(v, nullptr, 0) != 0;
        } else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose") ||
                   !strcmp(argv[i], "--debug")) {
            g_cfg.debug = true;
        } else if (!strcmp(argv[i], "--df-disable")) {
            g_cfg.df_enable = false;
        } else if (arg_value(argv[i], "--extcmd", &v)) {
            do_extcmd = true;
            extcmd_cmd = static_cast<int32_t>(strtol(v, nullptr, 0));
            const char* pc = strchr(v, ',');
            if (pc != nullptr) extcmd_param = static_cast<int32_t>(strtol(pc + 1, nullptr, 0));
        } else if (arg_value(argv[i], "--setfeature", &v)) {
            do_setfeature = true;
            setf_case = static_cast<int>(strtol(v, nullptr, 0));
            const char* c1 = strchr(v, ',');
            if (c1 != nullptr) {
                setf_mode = static_cast<int>(strtol(c1 + 1, nullptr, 0));
                const char* c2 = strchr(c1 + 1, ',');
                if (c2 != nullptr) setf_cookie = static_cast<int>(strtol(c2 + 1, nullptr, 0));
            }
            g_cfg.prop_param = v;
            g_cfg.prop_param_set = !g_cfg.prop_param.empty();
            g_cfg.aidl_code = static_cast<int>(strtol(v, nullptr, 0));
        } else if (arg_value(argv[i], "--runtime-mode", &v)) {
            g_cfg.runtime_mode = strtol(v, nullptr, 0) != 0;
        } else if (!strcmp(argv[i], "--read-only")) {
            g_cfg.runtime_mode = false;
        } else if (arg_value(argv[i], "--guard", &v)) {
            g_cfg.guard = strtol(v, nullptr, 0) != 0;
        } else if (arg_value(argv[i], "--debug", &v)) {
            g_cfg.debug = strtol(v, nullptr, 0) != 0;
        } else {
            fprintf(stderr, "%s: unknown argument '%s'\n", argv[0], argv[i]);
            usage(argv[0]);
            return 2;
        }
    }
    if (g_cfg.poll_ms < 0) {
        g_cfg.poll_ms = 0;      /* 0 = 阻塞等待（同 misf） */
    }

    setvbuf(stdout, nullptr, _IOLBF, 0);   /* line-buffered: live output */
    setvbuf(stderr, nullptr, _IOLBF, 0);
    ALOGI("fp_monitor v14 (build " __DATE__ " " __TIME__ ")");

    if (do_scan) {
        return scan(scan_dirs, 10);
    }
    if (have_write) {
        if (g_cfg.highlight_path.empty()) {
            fprintf(stderr, "--write needs %shighlight.path (or --highlight-path=PATH)\n", FP_PROP);
            return 2;
        }
        return highlight_write(write_value) ? 0 : 1;
    }
    const char* one_shot_fp_iface =
            "vendor.xiaomi.hardware.fingerprintextension.IXiaomiFingerprint/default";
    if (do_extcmd) {
        /* one-shot recovery tool: send extCmd(CMD, PARAM) exactly once.
         * Backend parameters fall back to the canonical values here only. */
        g_cfg.mode = g_cfg.mode.empty() ? "auto" : g_cfg.mode;
        g_cfg.mode_set = true;
        g_cfg.cmd = extcmd_cmd;
        g_cfg.cmd_set = true;
        if (g_cfg.hidl_instance.empty()) g_cfg.hidl_instance = "default";
        if (g_cfg.aidl_iface.empty()) g_cfg.aidl_iface = one_shot_fp_iface;
        if (g_cfg.aidl_code == 0) g_cfg.aidl_code = 1;
        ALOGI("--extcmd: sending extCmd(%d, %d) once", static_cast<int>(extcmd_cmd),
              static_cast<int>(extcmd_param));
        backend_send(extcmd_param);
        return 0;
    }
    if (do_setfeature) {
        /* one-shot: same convenience defaults, displayfeature side */
        if (g_cfg.df_mode.empty()) g_cfg.df_mode = "hidl";
        if (g_cfg.df_instance.empty()) g_cfg.df_instance = "default";
        if (g_cfg.df_aidl_iface.empty()) {
            g_cfg.df_aidl_iface = "vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default";
        }
        if (g_cfg.df_aidl_code == 0) g_cfg.df_aidl_code = 7;
        ALOGI("--setfeature: caseId=%d modeId=%d cookie=%d (df.mode=%s)", setf_case, setf_mode,
              setf_cookie, g_cfg.df_mode.c_str());
        return df_setfeature_vals(0, setf_case, setf_mode, setf_cookie) ? 0 : 1;
    }
    if (scan_input) {
        std::string dev = g_cfg.input_device.empty() ? std::string("/dev/input/event2")
                                                     : g_cfg.input_device;
        if (dev.find('/') == std::string::npos) {
            std::string r;
            for (int i = 0; i < 64 && r.empty(); i++) {
                char path[128];
                snprintf(path, sizeof(path), "/sys/class/input/event%d/device/name", i);
                int nfd = open(path, O_RDONLY | O_CLOEXEC);
                if (nfd < 0) continue;
                char name[128] = {0};
                int nr = read(nfd, name, sizeof(name) - 1);
                close(nfd);
                if (nr <= 0) continue;
                for (int k = 0; k < nr; k++) if (name[k] == '\n') name[k] = 0;
                if (dev == name) { snprintf(path, sizeof(path), "/dev/input/event%d", i); r = path; }
            }
            dev = r;
        }
        if (dev.empty()) { fprintf(stderr, "找不到设备\n"); return 1; }
        int fd = open(dev.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) { fprintf(stderr, "open %s 失败: %s\n", dev.c_str(), strerror(errno)); return 1; }
        printf("scan-input: %s —— 现在按指纹（5 秒）\n", dev.c_str());
        printf("%-8s %-16s %s\n", "type", "code", "value");
        int cnt[4096][2] = {{0}};
        for (int sec = 0; sec < 50; sec++) {
            unsigned char ev[24];
            ssize_t rr = read(fd, ev, sizeof(ev));
            if (rr == (ssize_t)sizeof(ev)) {
                uint16_t t = *reinterpret_cast<uint16_t*>(ev + 16);
                uint16_t c = *reinterpret_cast<uint16_t*>(ev + 18);
                int32_t val = *reinterpret_cast<int32_t*>(ev + 20);
                int key = (t & 0x3f) * 64 + (c & 0x3f);
                if (cnt[key][0]++ < 3) {
                    printf("%-8u %-16u %d\n", t, c, val);
                }
            } else {
                usleep(100 * 1000);
            }
        }
        printf("scan-input: 结束（重复的已折叠）\n");
        return 0;
    }
    if (do_probe) {
        return probe();
    }
    log_effective_config();
    dbglog("[boot] pid=%d trigger=%s path=%s poll_ms=%d", static_cast<int>(getpid()),
           effective_trigger(), g_cfg.path.c_str(), g_cfg.poll_ms);
    if (g_cfg.guard) {
        install_fault_guard();
    }

    if (once) {
        node_open();
        std::string raw;
        bool ok = node_read(&raw) == 1;
        bool state = ok && !raw.empty() && value_is_press(raw);
        ALOGI("state: readable=%d value=\"%s\" finger_down=%d", ok ? 1 : 0, raw.c_str(),
              state ? 1 : 0);
        if (!dry_run) {
            on_value(raw);
        }
        return 0;
    }

    const char* trig = effective_trigger();
    if (*trig == '\0') {
        ALOGW("trigger is not set: nothing is watched (set %strigger=node|timer|prop); idling",
              FP_PROP);
        while (true) {
            sleep(3600);
        }
    }
    if (strcmp(trig, "node") == 0 && g_cfg.path.empty()) {
        /* 不设 path = 不读节点，但**仍然发 extCmd**：直接按周期发，不做"读后再发"。
         * 启动立即发一次 param_down；收到 SIGINT/SIGTERM 时补一次 param_up。 */
        if (!g_cfg.cmd_set || !g_cfg.down_set) {
            ALOGW("未设置 %spath（不读节点），且未设置 extcmd.cmd/extcmd.down —— 无事可做，空闲",
                  FP_PROP);
            while (true) {
                sleep(3600);
            }
        }
        int period = g_cfg.period_ms > 0 ? g_cfg.period_ms : 1000;
        signal(SIGINT, fp_on_signal);
        signal(SIGTERM, fp_on_signal);
        ALOGI("未设置 %spath：不读节点，直接每 %dms 发 extCmd(%d, %d)；退出时发 param_up", FP_PROP,
              period, static_cast<int>(g_cfg.cmd), static_cast<int>(g_cfg.down));
        bool started = false;
        while (!g_stop) {
            backend_send(g_cfg.down);
            started = true;
            for (int i = 0; i < period / 100 && !g_stop; i++) {
                usleep(100 * 1000);
            }
        }
        if (started && g_cfg.up_set) {
            backend_send(g_cfg.up);
        }
        ALOGI("exit: 已发送 extCmd(%d, %d)", static_cast<int>(g_cfg.cmd),
              static_cast<int>(g_cfg.up));
        return 0;
    }
    if (strcmp(trig, "timer") == 0 && (g_cfg.period_ms <= 0 || !g_cfg.timer_param_set)) {
        ALOGW("trigger=timer needs %speriod_ms and %stimer.param -- idling", FP_PROP, FP_PROP);
        while (true) {
            sleep(3600);
        }
    }
    if (strcmp(trig, "prop") == 0 && (!g_cfg.prop_name_set || !g_cfg.prop_param_set)) {
        ALOGW("trigger=prop needs %sprop.name and %sprop.param -- idling", FP_PROP, FP_PROP);
        while (true) {
            sleep(3600);
        }
    }
    if (strcmp(trig, "node") != 0 && strcmp(trig, "timer") != 0 && strcmp(trig, "prop") != 0) {
        ALOGE("unknown %strigger=\"%s\" (expected node|timer|prop) -- idling", FP_PROP, trig);
        while (true) {
            sleep(3600);
        }
    }
    if (strcmp(trig, "timer") == 0) {
        ALOGI("trigger=timer: every %dms -> extCmd(%d, %d)", g_cfg.period_ms,
              static_cast<int>(g_cfg.cmd), g_cfg.timer_param);
        while (true) {
            usleep(static_cast<useconds_t>(g_cfg.period_ms) * 1000);
            backend_send(g_cfg.timer_param);
        }
        return 0;
    }
    if (strcmp(trig, "prop") == 0) {
        ALOGI("trigger=prop: %s == \"%s\" -> extCmd(%d, %d), otherwise extCmd(%d, %d)",
              g_cfg.prop_name.c_str(), g_cfg.prop_param.c_str(), static_cast<int>(g_cfg.cmd),
              g_cfg.down, static_cast<int>(g_cfg.cmd), g_cfg.up);
        std::string last_prop;
        bool have_prop = false;
        while (true) {
            char buf[PROP_VALUE_MAX] = {0};
            int n = __system_property_get(g_cfg.prop_name.c_str(), buf);
            std::string v = (n > 0) ? std::string(buf) : std::string();
            if (!have_prop || v != last_prop) {
                bool pressed = (!v.empty() && v == g_cfg.prop_param);
                ALOGI("prop %s=\"%s\" (%s)", g_cfg.prop_name.c_str(), v.c_str(),
                      pressed ? "pressed" : "released");
                if (!dry_run) {
                    backend_send(pressed ? g_cfg.down : g_cfg.up);
                }
                last_prop = v;
                have_prop = true;
            }
            usleep(static_cast<useconds_t>(g_cfg.poll_ms) * 1000);
        }
        return 0;
    }

    if (!g_cfg.prop_trigger.empty()) {
        ALOGI("触发源 = 系统属性 %s（不读节点）；值 == 1 视为按下，其余为抬起", g_cfg.prop_trigger.c_str());
        std::string lastv;
        bool have = false;
        while (true) {
            char buf[PROP_VALUE_MAX] = {0};
            int pn = __system_property_get(g_cfg.prop_trigger.c_str(), buf);
            std::string v = (pn > 0) ? std::string(buf) : std::string();
            if (!have || v != lastv) {
                bool pressed = (v == "1");
                ALOGI("%s=\"%s\" -> %s", g_cfg.prop_trigger.c_str(), v.c_str(),
                      pressed ? "pressed" : "released");
                on_value(pressed ? g_cfg.path_param : std::string("0"));
                lastv = v;
                have = true;
            }
            usleep(50 * 1000);   /* 20Hz，开销可忽略 */
        }
    }

    bool last = false; /* silent while idle */
    bool have_raw = false;
    std::string last_raw;
    int fail_count = 0;

    while (true) {
        if (g_src.fd < 0) {
            if (!node_open()) {
                if (++fail_count == 1 || (fail_count % 200) == 0) {
                    ALOGW("cannot open %s: %s (retrying)", g_cfg.path.c_str(), strerror(errno));
                }
                usleep(poll_delay_ms() * 1000);
                continue;
            }
            have_raw = false;
        }

        node_wait(g_cfg.poll_ms);

        std::string raw;
        if (node_read(&raw) != 1) {
            if (++fail_count == 1 || (fail_count % 200) == 0) {
                ALOGW("cannot read %s: %s (retrying)", g_cfg.path.c_str(), strerror(errno));
            }
            usleep(poll_delay_ms() * 1000);
            continue;
        }
        fail_count = 0;

        if (raw.empty() && !g_src.warned_empty) {
            g_src.warned_empty = true;
            ALOGW("%s reads back empty -- it is probably a write-only node. Use `%s --scan` to "
                  "find a readable trigger (fod_ui_ready / touch_finger_status) and point %spath "
                  "at it; keep this one for %shighlight.path.",
                  g_cfg.path.c_str(), "fp_monitor", FP_PROP, FP_PROP);
        }

        bool now = !raw.empty() && value_is_press(raw);

        if (!have_raw || raw != last_raw) {
            dbglog("[read] \"%s\" (last=\"%s\" now=%d)", raw.c_str(), last_raw.c_str(),
                   now ? 1 : 0);
            ALOGI("node value: \"%s\" (%s)", raw.c_str(), now ? "pressed" : "released");
            last_raw = raw;
            have_raw = true;
            on_value(raw);          /* 只在值变化时动作，避免轮询重复触发 */
        }
    }
    return 0;
}
