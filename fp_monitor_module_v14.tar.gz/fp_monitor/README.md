# fp_monitor

misf（A15）`FodMonitorThread::threadLoop()` 的进程外 **1:1 复刻**：读一个节点，按取值发
两条 HAL 调用（指纹扩展 extCmd + displayfeature setFeature）+ 写一个高亮节点。

**默认就是官方行为，不设任何属性也能用。**

## 默认行为

```
读 /sys/class/drm/card0-DSI-1/fod_ui_ready（阻塞等待）

读到 3   → setFeature(0,24,1,0) + disp_param=0x70000 + extCmd(10,1)
其它值   → 若已 start：setFeature(0,24,0,0) + extCmd(10,0) + disp_param=0x80000
通道     → AIDL 优先，失败回退 HIDL（运行期探测）
```
只在值变化时动作一次；只有 start 过才发 stop（misf 语义）。

## 属性（不设=用默认；设了=覆盖）

```sh
# 通道与节点
mifod.mode            auto                        # auto | hidl | aidl
mifod.path            /sys/class/drm/card0-DSI-1/fod_ui_ready
# extCmd
mifod.extcmd.cmd      10
mifod.extcmd.down     1
mifod.extcmd.up       0
mifod.extcmd.delay_ms 0                           # 发 extCmd 前等待 N 毫秒（misf 的 mSleepMs）
# 高亮
mifod.highlight.path        /sys/class/drm/card0-DSI-1/disp_param
mifod.highlight.value_on    0x70000
mifod.highlight.value_off   0x80000
# 可选：改用"读系统属性"触发（设了就不读节点；值非空且非 "0" 视为按下）
mifod.prop            (未设置)                    # 例：sys.fod.state
```

displayfeature 的 `caseId=24 / modeId=1,0 / cookie=0` 写死（misf 原值）。
把某条显式设成空（`setprop mifod.extcmd.down ""`）＝ 跳过那一步，只打一条 `skip …`，不会退出。

## 常用操作（复制即用）

```sh
# 跑 / 看日志（日志同时写到终端与 logcat）
./fp_monitor
./fp_monitor --debug

# 换通道 / 换节点
setprop mifod.mode aidl
setprop mifod.path /sys/class/drm/card0-DSI-1/xxx

# 自定义 extCmd / 高亮
setprop mifod.extcmd.cmd 10 ; setprop mifod.extcmd.down 1 ; setprop mifod.extcmd.up 0
setprop mifod.extcmd.delay_ms 50      # 发 extCmd 前等 50ms（0/不设 = 不等待）
setprop mifod.highlight.value_on 0x70000 ; setprop mifod.highlight.value_off 0x80000

# 用系统属性触发（UDFPS 里插 setprop）
setprop mifod.prop sys.fod.state
setprop sys.fod.state 1      # 按下
setprop sys.fod.state 0      # 抬起

# 复位（指纹卡在采集态）
./fp_monitor --extcmd=10,0
./fp_monitor --setfeature=24,0

# 清理属性（默认值本来就是 misf 的，清空即回到默认）
for k in mode path prop extcmd.cmd extcmd.down extcmd.up extcmd.delay_ms \
         highlight.path highlight.value_on highlight.value_off; do
    setprop mifod.$k ""
done
```

## 一次性动作

```
--probe                        打印节点值/配置/HAL 状态后退出
--scan[=DIR1,DIR2]             扫描可读节点，看哪些会变化
--write=VALUE                  往 mifod.highlight.path 写一次（找正确的高亮值）
--extcmd=CMD[,PARAM]           只发一次 extCmd
--setfeature=CASE,MODE[,COOKIE] 只调一次 displayfeature
--once / --dry-run / --help
```

## 日志怎么看

```
loaded /system_ext/lib64/...         接口库加载成功（/vendor 被 namespace 拒绝会先警告，可忽略）
auto: using HIDL                    通道探测结果
node value: "3" (pressed)           节点值变化（只在变化时打印）
displayfeature setFeature(… caseId=24 …)
highlight: <path> <- 0x70000        高亮写
extCmd(10, 1) -> 0                  extCmd 与返回值
skip … (not set)                    该步属性被设成空，跳过
```

## 部署

依赖全部来自 `/system/lib64`；两个厂商库按 `/vendor/lib64 → /system_ext/lib64 → /odm/lib64 → /system/lib64 → 自身目录`
顺序运行期 dlopen —— **不需要 RUNPATH/LD_LIBRARY_PATH，二进制放哪都能跑**。
作为服务运行时建议放在 Magisk 的 `service.sh` 里启动。包内的 `fp_monitor.rc` 使用自定义
SELinux 域 `u:r:fp_monitor:s0`，需要目标系统存在对应的策略定义；更换 ROM 时请先确认该域可用，
否则改用手动启动或 `service.sh`。

## 构建

```sh
cd standalone && ./build_standalone.sh      # 产物 out/fp_monitor
```
