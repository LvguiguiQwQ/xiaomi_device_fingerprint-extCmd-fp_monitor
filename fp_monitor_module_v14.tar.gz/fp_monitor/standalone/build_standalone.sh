#!/usr/bin/env bash
#
# build_standalone.sh — build fp_monitor without an AOSP tree.
#
# DT_RUNPATH is deliberately NOT written: library search is left to the caller
# (e.g. LD_LIBRARY_PATH).  Set FP_RUNPATH=/a:/b to bake one in when needed.
#
# The Xiaomi fingerprint extension HAL is a HIDL interface whose client side
# lives in /vendor/lib64/vendor.xiaomi.hardware.fingerprintextension@1.0.so.
# We cross-compile against the *real* libraries taken from the device, so the
# resulting binary links against exactly the code that will be loaded at
# runtime.  No generated HIDL headers are needed: standalone/fp_monitor_abi.h
# declares the interface ABI (see the comments in that file).
#
# Requirements (all of them are already prepared in /root/build on this device):
#   SYSROOT  bionic headers + libc++ headers + crt*.o   (Termux ndk-sysroot)
#   LIBS     copies of the device's own .so files
#
# Usage:  ./build_standalone.sh [output-dir]
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
SRC_TOP="${FP_SRC_TOP:-/root/build/src}"
SYSROOT="${FP_SYSROOT:-/root/build/termux/data/data/com.termux/files/usr}"
LIBS="${FP_LIBS:-/root/build/lib}"
OUT="${1:-$HERE/out}"

LIBHIDL="$SRC_TOP/android_system_libhidl-lineage-18.1"
LIBCXX="${FP_LIBCXX:-$SRC_TOP/android_external_libcxx-lineage-18.1/include}"
CORE="$SRC_TOP/android_system_core-lineage-18.1"

TARGET="aarch64-linux-android29"
CXX="${CXX:-clang++}"

mkdir -p "$OUT"

INCLUDES=(
    -I"$HERE/.."
    -I"$HERE"
    -I"$LIBHIDL/base/include"
    -I"$LIBHIDL/transport/include"
    -I"$CORE/libutils/include"
    -I"$CORE/libcutils/include"
    -isystem "$SYSROOT/include/aarch64-linux-android"
    -nostdinc++
    -isystem "$LIBCXX"
)

COMMON_FLAGS=(
    -Os
    -ffunction-sections
    -fdata-sections
    -fno-unwind-tables
    -fno-asynchronous-unwind-tables
    --target="$TARGET"
    --sysroot="$SYSROOT"
    -fPIE -fstack-protector-strong -Os -Wall -Wextra
    # Android-11 libc++ headers + Android-16 bionic headers: bionic already provides
    # the *_l() ctype inlines, so skip libc++'s fallback copies (include-guard hack).
    -D_LIBCPP_SUPPORT_XLOCALE_POSIX_L_FALLBACK_H
)

echo "== compiling fp_monitor.cc"
"$CXX" "${COMMON_FLAGS[@]}" "${INCLUDES[@]}" -c "$HERE/../fp_monitor.cc" -o "$OUT/fp_monitor.o"

echo "== linking"
LINK_LIBS=(

    -l:libhidlbase.so
    -l:libutils.so
    -l:liblog.so
    -l:libcutils.so
    -l:libbase.so

    -l:libbinder_ndk.so
    -l:libc++.so
    -l:libc.so
    -l:libm.so
    -l:libdl.so
)

"$CXX" "${COMMON_FLAGS[@]}" -pie -nostdlib \
    "$SYSROOT/lib/crtbegin_dynamic.o" \
    "$OUT/fp_monitor.o" \
    -L"$LIBS" "${LINK_LIBS[@]}" \
    -Wl,--dynamic-linker=/system/bin/linker64 \
    -Wl,--enable-new-dtags \
    ${FP_RUNPATH:+-Wl,-rpath,$FP_RUNPATH} \
    -Wl,-z,relro,-z,now \
    -Wl,--gc-sections -Wl,-s \
    -o "$OUT/fp_monitor" \
    "$SYSROOT/lib/crtend_android.o"

echo "== done: $OUT/fp_monitor"
file "$OUT/fp_monitor" 2>/dev/null || true
readelf -d "$OUT/fp_monitor" | grep -E "NEEDED|RUNPATH|SONAME" || true
